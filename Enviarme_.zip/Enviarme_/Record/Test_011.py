# matriz_gui_excel.py
import os
from datetime import datetime
from typing import Tuple, List, Dict, Optional

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# --- CONFIG ---
XLSX_PATH  = "Data_record.xlsx"   # r"C:\Users\Alex-PC\Desktop\python_Pro_Registros\Data_record.xlsx"
SHEET_NAME = "Records_"
TABLE_NAME = "DB_Records"

# Cada tabla vive en su propia hoja
SLC_ANNEX_SHEET        = "Slc_Annex_"
SLC_ANNEX_TABLE        = "Slc_Annex"          # columnas: ANNEX, DESCRIPTION, RESPONSIBLE AREA

SLC_INFO_SHEET         = "Slc_Info_"
SLC_INFO_TABLE         = "Slc_Info"           # columnas: ID, API, PRODUCT, CODES/CODE, CICLE, RAP PERIOD START, RAP PERIOD END, ...

SLC_DISTRIBUTION_SHEET = "Slc_Distribution_"
SLC_DISTRIBUTION_TABLE = "Slc_Distribution"   # (opcional)

DATE_FMT = "%d/%m/%Y"  # formato fuente de RAP PERIOD START/END

# Colores por estado (para pintar celdas de la matriz)
COLORS = {
    "Received & Scanned": "#c6efce",
    "Received": "#e2f0d9",
    "Scanned": "#ddebf7",
    "Pending Receipt": "#fff2cc",
    "Pending > 1 Month": "#f8cbad",
    "": "#ffffff",
}
PRIORITY = ["Pending > 1 Month", "Pending Receipt",
            "Received & Scanned", "Received", "Scanned", ""]

# Estilos de resaltado en la matriz
HOVER_HL_THICK = 2
SELECT_HL_THICK = 3
HL_COLOR = "#5b9bd5"

# Modificadores de teclado (comunes en Tk)
SHIFT_MASK  = 0x0001
CTRL_MASK   = 0x0004

NOW_FMT = "%Y-%m-%d %H:%M:%S"

# --- NUEVOS AJUSTES DE ANCHOS ---
# (1) Panel derecho (editor)
RIGHT_PANEL_WIDTH   = 340     # <<< hazlo más chico o grande a gusto
RIGHT_TEXT_WRAP     = RIGHT_PANEL_WIDTH - 40
INFO_KEY_WIDTH_CH   = 30
PLANT_COL_WIDTH_CH  = 18      # ancho de la columna "PL" en el editor
CHECK_COL_MINSIZE   = 44      # px de las 3 columnas de checks (R, S, PR)

# (2) Columna de ANEXOS (matriz izquierda)
ANNEX_COL_MINSIZE = 44        # píxeles mínimos de la columna 0 (anexos)
ANNEX_HDR_CH      = 5         # ancho del encabezado "Anexo" en caracteres
ANNEX_CELL_CH     = 4         # ancho de cada etiqueta de anexo (caracteres)

# ---------- HELPERS ----------
def _norm_id(x) -> str:
    s = str(x).strip()
    s2 = s.lstrip("0")
    return s if s2 == "" else s2

def _norm_annex(x) -> str:
    s = str(x).strip()
    if s.isdigit():
        s2 = s.lstrip("0")
        return s if s2 == "" else s2
    return s

def _safe_upper_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().upper() for c in df.columns]
    return df

def _nc(name: str) -> str:
    return "".join(ch for ch in str(name).upper() if ch.isalnum() or ch == "_")

def _get_val(d: Dict[str, str], *keys: str) -> str:
    for k in keys:
        if k in d:
            return d.get(k, "")
    return ""

def _fmt_date_dd_mmm(d: Optional[datetime]) -> str:
    if not d:
        return ""
    return d.strftime("%d-%b-%Y")

def _lighten(hex_color: str, factor: float) -> str:
    hex_color = hex_color.lstrip("#")
    if len(hex_color) != 6:
        return "#f5f5f5"
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    r = int(r + (255 - r) * factor)
    g = int(g + (255 - g) * factor)
    b = int(b + (255 - b) * factor)
    return f"#{r:02x}{g:02x}{b:02x}"

# ---------- UTILIDADES EXCEL ----------
def _excel_table_bounds(ws, table_name: str) -> Tuple[int, int, int, int]:
    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = tables[table_name]
    else:
        found = [tbl for tbl in tables if getattr(tbl, "name", None) == table_name]
        if not found:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = found[0]
    ref = t.ref
    min_row = ws[ref][0][0].row
    min_col = ws[ref][0][0].column
    max_row = ws[ref][-1][-1].row
    max_col = ws[ref][-1][-1].column
    return min_row, min_col, max_row, max_col

def read_excel_table(xlsx_path: str, sheet_name: str, table_name: str) -> pd.DataFrame:
    wb = load_workbook(xlsx_path, data_only=True, read_only=False)
    if sheet_name not in wb.sheetnames:
        wb.close(); raise ValueError(f"No existe la hoja '{sheet_name}'")
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)
    data = [list(r) for r in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2, values_only=True)]
    wb.close()
    if not data: return pd.DataFrame()
    headers = [str(h).strip() if h is not None else "" for h in data[0]]
    df = pd.DataFrame(data[1:], columns=headers)
    df = df.fillna("").astype(str)
    return df

def write_excel_table(df: pd.DataFrame, xlsx_path: str, sheet_name: str, table_name: str):
    if not os.path.exists(xlsx_path):
        raise FileNotFoundError(xlsx_path)
    wb = load_workbook(xlsx_path)
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)

    headers = list(df.columns)
    n_rows = len(df) + 1
    n_cols = len(headers)

    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = tables[table_name]
    else:
        found = [t for t in tables if getattr(t, "name", None) == table_name]
        if not found:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = found[0]

    end_row = r1 + n_rows - 1
    end_col = c1 + n_cols - 1
    table.ref = f"{get_column_letter(c1)}{r1}:{get_column_letter(end_col)}{end_row}"

    # Encabezados
    for j, val in enumerate(headers, start=c1):
        ws.cell(row=r1, column=j, value=val)

    # Limpia rango previo
    for rr in range(r1 + 1, r2 + 1):
        for cc in range(c1, c2 + 1):
            ws.cell(row=rr, column=cc, value=None)

    # Escribe datos
    for i in range(len(df)):
        for j in range(n_cols):
            ws.cell(row=r1 + 1 + i, column=c1 + j, value=df.iat[i, j])

    wb.save(xlsx_path); wb.close()

# ---------- LÓGICA ESTADOS ----------
def parse_date_ddmmyyyy(s: str) -> Optional[datetime]:
    s = (s or "").strip()
    if not s: return None
    for fmt in (DATE_FMT, "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    return None

def _row_pr_overdue(row: pd.Series) -> bool:
    rap = parse_date_ddmmyyyy(str(row.get("RAP PERIOD END", "")).strip())
    if not rap:
        return False
    days_over = (datetime.today().date() - rap.date()).days
    return days_over > 30

def derive_status_per_row(row: pd.Series) -> str:
    def _is_on(v: str) -> bool:
        s = str(v).strip().lower()
        return s in ("1", "true", "sí", "si", "x")
    r = _is_on(row.get("Received", ""))
    s = _is_on(row.get("Scanned", ""))
    pr = _is_on(row.get("Pending Receipt", ""))

    if r:
        pr = False

    if pr:
        return "Pending > 1 Month" if _row_pr_overdue(row) else "Pending Receipt"
    if r and s: return "Received & Scanned"
    if r: return "Received"
    if s: return "Scanned"
    return ""

def compute_persisted_fields(received: str, scanned: str, pending_r: str, rap_end: str) -> Dict[str, str]:
    rs = "1" if (received == "1" and scanned == "1") else ""
    pgt = ""
    if pending_r == "1":
        rap = parse_date_ddmmyyyy(rap_end)
        overdue = rap is not None and (datetime.today().date() - rap.date()).days > 30
        pgt = "1" if overdue else ""
    return {"Received & Scanned": rs, "Pending > 1 Month": pgt}

def summarize_group_status(states: List[str]) -> str:
    for state in PRIORITY:
        if state and state in states:
            return state
    return ""

# ---------- APP ----------
class MatrixApp(tk.Tk):
    def __init__(self, xlsx_path: str, sheet: str, table: str):
        super().__init__()
        self.title("AERR | Annex Tracking System")
        self.geometry("1380x880")

        self.xlsx_path = xlsx_path
        self.sheet = sheet
        self.table = table

        try:
            self.df = read_excel_table(self.xlsx_path, self.sheet, self.table)
        except Exception as e:
            messagebox.showerror("Error al leer Excel", str(e)); self.destroy(); return

        required_cols = ["ID","ANNEX","PLANT","CICLE","Received","Scanned","Pending Receipt","RAP PERIOD END","Updated on"]
        for col in required_cols:
            if col not in self.df.columns:
                self.df[col] = ""

        self._dirty_indices: set[int] = set()

        # ====== Slc_Annex: ANNEX -> DESCRIPTION, RESPONSIBLE AREA ======
        self.annex_desc: Dict[str, str] = {}
        self.annex_resp: Dict[str, str] = {}
        try:
            df_cat = read_excel_table(self.xlsx_path, SLC_ANNEX_SHEET, SLC_ANNEX_TABLE)
            df_cat = _safe_upper_columns(df_cat)
            cols_norm = {_nc(c): c for c in df_cat.columns}
            annex_col = cols_norm.get("ANNEX")
            desc_col  = cols_norm.get("DESCRIPTION")
            resp_col  = (cols_norm.get("RESPONSIBLEAREA") or cols_norm.get("RESPONSIBLE_AREA")
                         or cols_norm.get("RESPAREA") or cols_norm.get("RESPONSIBLE"))
            for _, r in df_cat.iterrows():
                raw_key = r.get(annex_col, "") if annex_col else ""
                key = _norm_annex(raw_key)
                if not key:
                    continue
                if desc_col:
                    self.annex_desc[key] = str(r.get(desc_col, "")).strip()
                if resp_col:
                    self.annex_resp[key] = str(r.get(resp_col, "")).strip()
        except Exception:
            pass

        # ====== Slc_Info (clave: ID) ======
        self.info_rows_by_id: Dict[str, List[Dict[str, str]]] = {}

        def _ingest_info_df(df_src: pd.DataFrame):
            df_i = _safe_upper_columns(df_src).fillna("")
            if "ID" not in df_i.columns:
                return
            for _, r in df_i.iterrows():
                rid = _norm_id(r.get("ID", ""))
                if not rid:
                    continue
                row_dict = {k: str(r.get(k, "")).strip() for k in df_i.columns}
                self.info_rows_by_id.setdefault(rid, []).append(row_dict)

        try:
            df_info_tbl = read_excel_table(self.xlsx_path, SLC_INFO_SHEET, SLC_INFO_TABLE)
            if not df_info_tbl.empty:
                _ingest_info_df(df_info_tbl)
        except Exception:
            pass

        if not self.info_rows_by_id:
            try:
                df_sheet = pd.read_excel(self.xlsx_path, sheet_name=SLC_INFO_SHEET, dtype=str)
                _ingest_info_df(df_sheet)
            except Exception:
                pass

        if not self.info_rows_by_id:
            messagebox.showwarning(
                "Slc_Info no encontrada",
                ("No se pudo leer la tabla 'Slc_Info' en la hoja 'Slc_Info_'. "
                 "Asegúrate de que exista una tabla llamada 'Slc_Info' en esa hoja "
                 "o que la hoja contenga columnas ID, API, PRODUCT, CODES (o CODE), "
                 "CICLE, RAP PERIOD START, RAP PERIOD END.")
            )

        # ====== Slc_Distribution (opcional) ======
        self.df_distribution: pd.DataFrame = pd.DataFrame()
        try:
            df_dist_tbl = read_excel_table(self.xlsx_path, SLC_DISTRIBUTION_SHEET, SLC_DISTRIBUTION_TABLE)
            self.df_distribution = _safe_upper_columns(df_dist_tbl)
        except Exception:
            try:
                self.df_distribution = _safe_upper_columns(
                    pd.read_excel(self.xlsx_path, sheet_name=SLC_DISTRIBUTION_SHEET, dtype=str).fillna("")
                )
            except Exception:
                self.df_distribution = pd.DataFrame()

        # ====== LAYOUT ======
        self.toolbar = ttk.Frame(self); self.toolbar.pack(fill="x", padx=10, pady=(8,4))
        self._build_toolbar(self.toolbar)

        self.legend = ttk.Frame(self); self.legend.pack(fill="x", padx=10, pady=(0,8))
        self._build_legend(self.legend)

        self.content = ttk.Frame(self); self.content.pack(fill="both", expand=True, padx=10, pady=6)
        self._build_matrix(self.content)
        self._build_editor(self.content)

        # Estado UI
        self.cells: Dict[tuple, Dict] = {}
        self.current_group_key: tuple | None = None

        # Navegación
        self.ids: List[str] = []
        self.anexos: List[str] = []
        self.group_exists: Dict[tuple, bool] = {}

        # Selección múltiple
        self.selected_keys: set[tuple] = set()
        self.anchor_key: tuple | None = None

        self.bind_all("<Up>", self._on_key_up)
        self.bind_all("<Down>", self._on_key_down)
        self.bind_all("<Left>", self._on_key_left)
        self.bind_all("<Right>", self._on_key_right)

        self.bind_all("<Control-s>", lambda e: self.save_to_excel())

        self.render_matrix()

    # ---------- MOUSE WHEEL SCROLL ----------
    def _bind_mousewheel(self, widget, xview=None, yview=None):
        if yview:
            widget.bind("<MouseWheel>", lambda e: yview("scroll", int(-e.delta/120), "units"))
            widget.bind("<Button-4>",  lambda e: yview("scroll", -1, "units"))
            widget.bind("<Button-5>",  lambda e: yview("scroll",  1, "units"))
        if xview:
            widget.bind("<Shift-MouseWheel>", lambda e: xview("scroll", int(-e.delta/120), "units"))

    # --- Selector de mejor fila de Slc_Info ---
    def _pick_info_row(self, id_str: str, anex: str, cicle_selected: str) -> Optional[Dict[str, str]]:
        rid = _norm_id(id_str)
        rows = self.info_rows_by_id.get(rid, []) or self.info_rows_by_id.get(str(id_str).strip(), [])
        if not rows:
            return None
        for r in rows:
            annex_val = r.get("ANNEX", "")
            if _norm_annex(annex_val) == _norm_annex(anex):
                return r
        for r in rows:
            if str(r.get("CICLE", "")).strip() == str(cicle_selected).strip():
                return r
        return rows[0]

    # --- TOOLBAR ---
    def _build_toolbar(self, parent):
        ttk.Label(parent, text="Ciclo:").pack(side="left")
        cycles = sorted(self.df["CICLE"].astype(str).unique(), key=lambda x: (len(x), x))
        self.cb_cycle = ttk.Combobox(parent, values=cycles, state="readonly", width=12, justify="center")
        if cycles: self.cb_cycle.current(0)
        self.cb_cycle.pack(side="left", padx=6)
        self.cb_cycle.bind("<<ComboboxSelected>>", lambda e: self._reload_and_commit())

        btn_save = ttk.Button(parent, text="Save (Ctrl+S)", command=self.save_to_excel)
        btn_save.pack(side="left", padx=4)

        ttk.Label(parent, text="Filter by status").pack(side="left", padx=(24,4))
        self.filter_states = ["(All)", "Received & Scanned", "Received", "Scanned", "Pending Receipt", "Pending > 1 Month"]
        self.filter_state = ttk.Combobox(parent, values=self.filter_states, state="readonly", width=22, justify="center")
        self.filter_state.current(0)
        self.filter_state.pack(side="left", padx=(0,4))
        self.filter_state.bind("<<ComboboxSelected>>", lambda e: self._reload_and_commit())

        ttk.Button(parent, text="Set Received", command=lambda: self._bulk_apply("R")).pack(side="left", padx=2)
        ttk.Button(parent, text="Set Scanned", command=lambda: self._bulk_apply("S")).pack(side="left", padx=2)
        ttk.Button(parent, text="Set Pending", command=lambda: self._bulk_apply("PR")).pack(side="left", padx=2)
        ttk.Button(parent, text="Clear Checks", command=self._bulk_clear).pack(side="left", padx=6)

    # --- LEYENDA ---
    def _build_legend(self, parent):
        for s in ["Received & Scanned", "Received", "Scanned", "Pending Receipt", "Pending > 1 Month"]:
            tk.Label(parent, text="  ", bg=COLORS[s], relief="groove", width=3).pack(side="left", padx=5, pady=2)
            ttk.Label(parent, text=s).pack(side="left", padx=(0,12))

    # --- MATRIZ (izquierda) ---
    def _build_matrix(self, parent):
        left = ttk.Frame(parent); left.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(left, borderwidth=0, highlightthickness=0)
        self.grid_frame = ttk.Frame(self.canvas)
        self.canvas_window = self.canvas.create_window((0,0), window=self.grid_frame, anchor="nw")

        self.scroll_y = ttk.Scrollbar(left, orient="vertical", command=self.canvas.yview)
        self._hscroll_visible = False
        self.canvas.configure(yscrollcommand=self.scroll_y.set)

        self.scroll_x = ttk.Scrollbar(left, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(xscrollcommand=self.scroll_x.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll_y.pack(side="right", fill="y")

        self.grid_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: (self.canvas.itemconfig(self.canvas_window, width=e.width), self._toggle_horizontal_scrollbar()))

        self._bind_mousewheel(self.canvas, xview=self.canvas.xview, yview=self.canvas.yview)
        self.grid_frame.bind("<Enter>", lambda e: self.canvas.focus_set())

    def _toggle_horizontal_scrollbar(self):
        self.canvas.update_idletasks()
        need = self.grid_frame.winfo_reqwidth() > self.canvas.winfo_width()
        if need and not self._hscroll_visible:
            self._hscroll_visible = True
            self.scroll_x.pack(side="bottom", fill="x")
        elif not need and self._hscroll_visible:
            self._hscroll_visible = False
            self.scroll_x.pack_forget()

    # --- EDITOR (derecha) ---
    def _build_editor(self, parent):
        right = ttk.Frame(parent, width=RIGHT_PANEL_WIDTH); right.pack(side="right", fill="y")
        right.pack_propagate(False)  # fija el ancho del panel derecho

        # Encabezado (ANNEX=…) y DESCRIPTION en la línea siguiente
        self.editor_info = ttk.Label(right, text="ANNEX:", font=("Segoe UI", 10, "bold"))
        self.editor_info.pack(anchor="w", pady=(0,2))
        self.editor_desc = ttk.Label(right, text="", font=("Segoe UI", 9),
                                     wraplength=RIGHT_TEXT_WRAP, justify="left")
        self.editor_desc.pack(anchor="w", pady=(0,8))

        # Panel de datos del ID (Slc_Info)
        self.info_panel = ttk.Frame(right)
        self.info_panel.pack(fill="x", pady=(0,8))
        # la columna 1 (valores) se expande
        self.info_panel.grid_columnconfigure(1, weight=1)

        self.info_labels = [
            ("API", None),
            ("PRODUCT", None),
            ("CODES", None),
            ("ANNEX DEADLINE (8 WEEKS / 56 DAYS)", None),
            ("REPORT ISSUANCE (90 DAYS)", None),
            ("DEADLINE FOR SIGNING (120 DAYS)", None),
        ]
        for i, (k, _) in enumerate(self.info_labels):
            ttk.Label(self.info_panel, text=k + ":", width=INFO_KEY_WIDTH_CH, anchor="e").grid(
                row=i, column=0, sticky="e", padx=(0,6), pady=1)
            val = ttk.Label(self.info_panel, text="", wraplength=RIGHT_TEXT_WRAP, justify="left", anchor="w")
            val.grid(row=i, column=1, sticky="ew", pady=1)
            self.info_labels[i] = (k, val)

        # Encabezados mini centrados
        hdr = ttk.Frame(right); hdr.pack(fill="x", pady=(2,2))
        head_font = ("Segoe UI", 8, "bold")
        ttk.Label(hdr, text="PL", font=head_font, width=PLANT_COL_WIDTH_CH, anchor="center").grid(row=0, column=0, padx=(2,2), sticky="nsew")
        ttk.Label(hdr, text="R",  font=head_font, anchor="center").grid(row=0, column=1, padx=(4,4), sticky="nsew")
        ttk.Label(hdr, text="S",  font=head_font, anchor="center").grid(row=0, column=2, padx=(4,4), sticky="nsew")
        ttk.Label(hdr, text="PR", font=head_font, anchor="center").grid(row=0, column=3, padx=(4,4), sticky="nsew")

        # Contenedor scrollable (para muchas plantas)
        body = ttk.Frame(right); body.pack(fill="both", expand=True)
        self.sub_canvas = tk.Canvas(body, height=480, borderwidth=0, highlightthickness=0)
        self.sub_frame = ttk.Frame(self.sub_canvas)
        self.sub_scroll = ttk.Scrollbar(body, orient="vertical", command=self.sub_canvas.yview)
        self.sub_canvas.configure(yscrollcommand=self.sub_scroll.set)

        self.sub_canvas.grid(row=0, column=0, sticky="nsew")
        self.sub_scroll.grid(row=0, column=1, sticky="ns")
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        self.sub_window = self.sub_canvas.create_window((0,0), window=self.sub_frame, anchor="nw")
        self.sub_frame.bind("<Configure>", lambda e: self.sub_canvas.configure(scrollregion=self.sub_canvas.bbox("all")))
        self.sub_canvas.bind("<Configure>", lambda e: self.sub_canvas.itemconfig(self.sub_window, width=e.width))

        # Alineación uniforme de columnas para los checks
        self.sub_frame.grid_columnconfigure(0, weight=1)  # PL ocupa el resto
        for col in (1, 2, 3):
            self.sub_frame.grid_columnconfigure(col, weight=0, uniform="chk", minsize=CHECK_COL_MINSIZE)

    # ---------- RENDER / RELOAD ----------
    def _reload_and_commit(self):
        self._commit_editor_changes_to_df()
        self.render_matrix()

    def _header_text_for_id(self, pid: str) -> str:
        selected_cicle = self.cb_cycle.get()
        rid = _norm_id(pid)
        rows = self.info_rows_by_id.get(rid, []) or self.info_rows_by_id.get(str(pid).strip(), [])
        chosen = None
        if rows:
            for r in rows:
                if str(r.get("CICLE", "")).strip() == str(selected_cicle).strip():
                    chosen = r; break
            if not chosen:
                chosen = rows[0]

        api = _get_val(chosen or {}, "API")
        d_s = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD START"))
        d_e = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD END"))
        s_fmt = _fmt_date_dd_mmm(d_s)
        e_fmt = _fmt_date_dd_mmm(d_e)
        rng = f"{s_fmt} al {e_fmt}" if (s_fmt or e_fmt) else ""

        lines = []
        if api: lines.append(str(api))
        if rng: lines.append(rng)
        return "\n".join(lines) if lines else ""

    def _cell_summary_lines(self, grp: pd.DataFrame, key: tuple) -> (str, str, List[str]):
        states = grp["__state__"].tolist()
        group_state = summarize_group_status(states)
        bg = COLORS.get(group_state, "#ffffff")

        lines = [group_state if group_state else ""]
        resp = self.annex_resp.get(_norm_annex(key[1]), "")
        if resp:
            lines.append(f"Responsible Area: {resp}")

        for _, r in grp.iterrows():
            plant = (r.get("PLANT","") or "").strip()
            st = r["__state__"]
            if st == "Pending > 1 Month":
                mini = "!!"
            elif st == "Pending Receipt":
                mini = "!"
            elif st == "Received & Scanned":
                mini = "✓✓"
            elif st == "Received":
                mini = "✓"
            elif st == "Scanned":
                mini = "S"
            else:
                mini = "-"
            lines.append(f"{plant}: {mini}")
        return group_state, bg, lines

    def render_matrix(self):
        for w in self.grid_frame.winfo_children():
            w.destroy()
        self.cells.clear()
        self._clear_editor()
        self.current_group_key = None
        self.selected_keys.clear()
        self.anchor_key = None

        df = self.df.copy()

        selected = self.cb_cycle.get()
        if selected:
            df = df[df["CICLE"].astype(str) == selected]

        df["__state__"] = df.apply(derive_status_per_row, axis=1)

        state_filter = getattr(self, "filter_state", None)
        if state_filter:
            sel_state = state_filter.get()
            if sel_state and sel_state != "(All)":
                df = df[df["__state__"] == sel_state]

        self.ids = list(dict.fromkeys([_norm_id(x) for x in df["ID"].astype(str).tolist()]))
        try:
            self.anexos = sorted({int(_norm_annex(x)) for x in df["ANNEX"].astype(str).tolist() if str(x).strip().isdigit()})
            self.anexos = [str(a) for a in self.anexos]
        except Exception:
            self.anexos = list(dict.fromkeys([_norm_annex(x) for x in df["ANNEX"].astype(str).tolist()]))
        if not self.anexos:
            self.anexos = [str(i) for i in range(1,19)]
        self.anexos = list(dict.fromkeys([_norm_annex(a) for a in self.anexos]))

        self.group_exists = {}
        for pid in self.ids:
            for an in self.anexos:
                exists = len(df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                                (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(an))]) > 0
                self.group_exists[(str(pid), str(an))] = exists

        # Encabezados
        tk.Label(self.grid_frame, text="Anexo", relief="ridge",
                 width=ANNEX_HDR_CH, justify="center").grid(row=0, column=0, sticky="nsew")
        for j, pid in enumerate(self.ids, start=1):
            header_txt = self._header_text_for_id(pid)
            tk.Label(self.grid_frame, text=header_txt, relief="ridge", width=22,
                     justify="center", wraplength=170).grid(row=0, column=j, sticky="nsew")

        # Celdas
        for i, an in enumerate(self.anexos, start=1):
            tk.Label(self.grid_frame, text=str(an), relief="ridge",
                     width=ANNEX_CELL_CH, justify="center").grid(row=i, column=0, sticky="nsew")
            for j, pid in enumerate(self.ids, start=1):
                grp = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                         (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(an))]
                key = (str(pid), str(an))
                if len(grp)==0:
                    lbl = tk.Label(self.grid_frame, text="", bg="#eeeeee", relief="groove", width=22, height=2)
                    lbl.grid(row=i, column=j, sticky="nsew", padx=1, pady=1)
                    continue

                _, bg, lines = self._cell_summary_lines(grp, key)

                if len(grp) >= 3:
                    cell = tk.Canvas(self.grid_frame, width=220, height=90, highlightbackground=HL_COLOR,
                                     highlightcolor=HL_COLOR, highlightthickness=0, bd=0)
                    cell.grid(row=i, column=j, sticky="nsew", padx=1, pady=1)
                    z1 = _lighten(bg, 0.35)
                    z2 = _lighten(bg, 0.55)
                    h = 90
                    n = max(3, len(lines))
                    stripe_h = int(h / n)
                    for k in range(n):
                        color = z1 if k % 2 == 0 else z2
                        cell.create_rectangle(0, k*stripe_h, 1000, (k+1)*stripe_h, fill=color, width=0)
                    y = 12
                    for ln in lines:
                        cell.create_text(110, y, text=ln, anchor="n", width=200, justify="center")
                        y += stripe_h
                    widget = cell
                else:
                    lbl = tk.Label(self.grid_frame, text="\n".join([ln for ln in lines if ln]),
                                   bg=bg, relief="groove", width=22, height=5, wraplength=170,
                                   justify="center", highlightbackground=HL_COLOR,
                                   highlightcolor=HL_COLOR, highlightthickness=0)
                    lbl.grid(row=i, column=j, sticky="nsew", padx=1, pady=1)
                    widget = lbl

                self.cells[key] = {"widget": widget, "group_indexes": grp.index.tolist(), "bg": bg,
                                   "row": i, "col": j}
                widget.bind("<Enter>", lambda e, k=key: self._on_cell_hover_enter(k))
                widget.bind("<Leave>", lambda e, k=key: self._on_cell_hover_leave(k))
                widget.bind("<Button-1>", lambda e, k=key: self._on_cell_click(k, e))

        # Distribución de pesos: columna 0 fija y angosta, resto expandibles
        self.grid_frame.grid_columnconfigure(0, weight=0, minsize=ANNEX_COL_MINSIZE)
        for c in range(1, len(self.ids)+1):
            self.grid_frame.grid_columnconfigure(c, weight=1)

        self._toggle_horizontal_scrollbar()

    # ---------- HOVER / SELECCIÓN ----------
    def _on_cell_hover_enter(self, key):
        info = self.cells.get(key)
        if not info: return
        info["widget"].config(highlightthickness=HOVER_HL_THICK)

    def _on_cell_hover_leave(self, key):
        info = self.cells.get(key)
        if not info: return
        if key in self.selected_keys:
            info["widget"].config(highlightthickness=SELECT_HL_THICK)
        else:
            info["widget"].config(highlightthickness=0)

    def _set_selected_visual(self, key, on: bool):
        info = self.cells.get(key)
        if not info: return
        w = info["widget"]
        w.config(highlightthickness=SELECT_HL_THICK if on else 0)

    def _clear_all_selection(self):
        for k in list(self.selected_keys):
            self._set_selected_visual(k, False)
        self.selected_keys.clear()
        self.anchor_key = None

    def _range_between_keys(self, a: tuple, b: tuple) -> list[tuple]:
        if a not in self.cells or b not in self.cells: return []
        ai, aj = self.cells[a]["row"], self.cells[a]["col"]
        bi, bj = self.cells[b]["row"], self.cells[b]["col"]
        r1, r2 = sorted((ai, bi)); c1, c2 = sorted((aj, bj))
        keys = []
        for i in range(r1, r2+1):
            for j in range(c1, c2+1):
                if j == 0 or i == 0: continue
                pid = self.ids[j-1]; an = self.anexos[i-1]
                k = (str(pid), str(an))
                if self.group_exists.get(k):
                    keys.append(k)
        return keys

    def _ensure_cell_visible(self, key: tuple):
        info = self.cells.get(key)
        if not info: return
        w = info["widget"]
        self.canvas.update_idletasks()

        y = w.winfo_y()
        h = w.winfo_height()
        x = w.winfo_x()
        wd = w.winfo_width()

        top = self.canvas.canvasy(0)
        bottom = top + self.canvas.winfo_height()
        left = self.canvas.canvasx(0)
        right = left + self.canvas.winfo_width()

        total_h = max(1, self.grid_frame.winfo_height())
        if y < top:
            self.canvas.yview_moveto(y / total_h)
        elif y + h > bottom:
            self.canvas.yview_moveto((y + h - self.canvas.winfo_height()) / total_h)

        total_w = max(1, self.grid_frame.winfo_width())
        if x < left:
            self.canvas.xview_moveto(x / total_w)
        elif x + wd > right:
            self.canvas.xview_moveto((x + wd - self.canvas.winfo_width()) / total_w)

    def _on_cell_click(self, key, event=None):
        self._commit_editor_changes_to_df()

        ctrl = bool(event and (event.state & CTRL_MASK))
        shift = bool(event and (event.state & SHIFT_MASK))

        if shift and not self.anchor_key:
            self.anchor_key = self.current_group_key or key

        if shift and self.anchor_key:
            new_keys = self._range_between_keys(self.anchor_key, key)
            if not ctrl:
                self._clear_all_selection()
            for k in new_keys:
                if k not in self.selected_keys:
                    self.selected_keys.add(k)
                    self._set_selected_visual(k, True)
        elif ctrl:
            if key in self.selected_keys:
                self.selected_keys.remove(key)
                self._set_selected_visual(key, False)
            else:
                self.selected_keys.add(key)
                self._set_selected_visual(key, True)
                self.anchor_key = key
        else:
            self._clear_all_selection()
            self.selected_keys.add(key)
            self._set_selected_visual(key, True)
            self.anchor_key = key

        self.current_group_key = key
        self._load_group_in_editor(key)
        self._ensure_cell_visible(key)
        self.focus_set()

    # ---------- NAVEGACIÓN CON FLECHAS ----------
    def _move_selection(self, drow: int, dcol: int):
        if not self.current_group_key:
            for an in self.anexos:
                for pid in self.ids:
                    if self.group_exists.get((pid, an)):
                        self._on_cell_click((pid, an)); return
            return

        cur_id, cur_an = self.current_group_key
        try:
            r = self.anexos.index(str(cur_an))
            c = self.ids.index(str(cur_id))
        except ValueError:
            return

        visited = set()
        nr, nc = r, c
        while True:
            nr = max(0, min(len(self.anexos)-1, nr + drow))
            nc = max(0, min(len(self.ids)-1, nc + dcol))
            candidate = (self.ids[nc], self.anexos[nr])
            if candidate in visited:
                break
            visited.add(candidate)
            if self.group_exists.get(candidate):
                self._on_cell_click(candidate)
                self._ensure_cell_visible(candidate)
                return
            if (nr in (0, len(self.anexos)-1) and drow != 0) and (nc in (0, len(self.ids)-1) and dcol != 0):
                break

    def _on_key_up(self, event): self._move_selection(-1, 0)
    def _on_key_down(self, event): self._move_selection(1, 0)
    def _on_key_left(self, event): self._move_selection(0, -1)
    def _on_key_right(self, event): self._move_selection(0, 1)

    # ---------- EDITOR ----------
    def _clear_editor(self):
        for w in self.sub_frame.winfo_children():
            w.destroy()
        self.editor_info.configure(text="ANNEX=", font=("Segoe UI", 10, "bold"))
        self.editor_desc.configure(text="")
        self.editor_rows = []
        if hasattr(self, "info_labels"):
            for _, lbl in self.info_labels:
                lbl.configure(text="")

    def _build_global_totals_panel(self, parent):
        if hasattr(self, "global_frame") and self.global_frame.winfo_exists():
            self.global_frame.destroy()

        self.global_frame = ttk.Frame(parent)
        # ahora el editor tiene 4 columnas (0..3)
        self.global_frame.grid(row=self._editor_next_row, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        for col in range(3):
            self.global_frame.grid_columnconfigure(col, weight=1)

        self.global_hdr_var = tk.StringVar(value="All files in current view: 0")
        ttk.Label(self.global_frame, textvariable=self.global_hdr_var,
                  font=("Segoe UI", 9, "bold"), anchor="center").grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 6))

        header_font = ("Segoe UI", 9, "bold")
        ttk.Label(self.global_frame, text=" ", anchor="center").grid(row=1, column=0, sticky="ew")
        ttk.Label(self.global_frame, text="Total files", font=header_font, anchor="center").grid(row=1, column=1, sticky="ew")
        ttk.Label(self.global_frame, text="% Total files", font=header_font, anchor="center").grid(row=1, column=2, sticky="ew")

        rows = ["Received", "Scanned", "Pending Receipt"]
        self.global_tbl_vars = {}
        for i, rname in enumerate(rows, start=2):
            ttk.Label(self.global_frame, text=rname, anchor="center").grid(row=i, column=0, sticky="ew", padx=(0, 6))
            v_total = tk.StringVar(value="0")
            v_pct   = tk.StringVar(value="0.0%")
            ttk.Label(self.global_frame, textvariable=v_total, anchor="center", relief="groove").grid(row=i, column=1, sticky="ew", padx=(0, 6))
            ttk.Label(self.global_frame, textvariable=v_pct,   anchor="center", relief="groove").grid(row=i, column=2, sticky="ew")
            self.global_tbl_vars[rname] = (v_total, v_pct)

    def _update_global_table_inline(self):
        if not hasattr(self, "global_tbl_vars"):
            return

        df = self.df.copy()
        selected = self.cb_cycle.get()
        if selected:
            df = df[df["CICLE"].astype(str) == selected]
        df["__state__"] = df.apply(derive_status_per_row, axis=1)

        sel_state = self.filter_state.get() if getattr(self, "filter_state", None) else "(All)"
        if sel_state and sel_state != "(All)":
            df = df[df["__state__"] == sel_state]

        existing_groups = 0
        for pid in self.ids:
            for anex in self.anexos:
                if self.group_exists.get((pid, anex)):
                    existing_groups += 1

        total_files = existing_groups
        self.global_hdr_var.set(f"All files in current view: {total_files}")

        received_groups = scanned_groups = pending_groups = 0
        for pid in self.ids:
            for anex in self.anexos:
                if not self.group_exists.get((pid, anex)):
                    continue
                grp = df[(df["ID"].astype(str).map(_norm_id) == _norm_id(pid)) &
                         (df["ANNEX"].astype(str).map(_norm_annex) == _norm_annex(anex))]
                if grp.empty:
                    continue
                group_state = summarize_group_status(grp["__state__"].tolist())
                if group_state in ("Received", "Received & Scanned"):
                    received_groups += 1
                if group_state in ("Scanned", "Received & Scanned"):
                    scanned_groups += 1
                if group_state.startswith("Pending"):
                    pending_groups += 1

        def pct(n):
            return f"{(n/total_files*100):.1f}%" if total_files > 0 else "0.0%"

        self.global_tbl_vars["Received"][0].set(str(received_groups))
        self.global_tbl_vars["Received"][1].set(pct(received_groups))
        self.global_tbl_vars["Scanned"][0].set(str(scanned_groups))
        self.global_tbl_vars["Scanned"][1].set(pct(scanned_groups))
        self.global_tbl_vars["Pending Receipt"][0].set(str(pending_groups))
        self.global_tbl_vars["Pending Receipt"][1].set(pct(pending_groups))

    def _load_group_in_editor(self, key: tuple):
        self._clear_editor()
        id_, anex = key

        # Encabezado y DESCRIPTION justo debajo
        self.editor_info.configure(text=f"ANNEX={anex}", font=("Segoe UI", 10, "bold"))
        self.editor_desc.configure(text=self.annex_desc.get(_norm_annex(anex), ""))

        selected_cicle = self.cb_cycle.get()
        info = self._pick_info_row(str(id_), str(anex), str(selected_cicle)) or {}

        codes_val = _get_val(info, "CODES", "CODE")

        def _fmt_cell(v: str, is_date: bool = False) -> str:
            if not is_date:
                return v or ""
            d = parse_date_ddmmyyyy(v)
            return _fmt_date_dd_mmm(d) if d else (v or "")

        date_keys = {
            "ANNEX DEADLINE (8 WEEKS / 56 DAYS)",
            "REPORT ISSUANCE (90 DAYS)",
            "DEADLINE FOR SIGNING (120 DAYS)",
        }

        for k, lbl in self.info_labels:
            if k == "CODES":
                lbl.configure(text=codes_val)
            else:
                val = info.get(k, "")
                lbl.configure(text=_fmt_cell(val, k in date_keys))

        # Sub-filas por planta (editor de checks) — alineado
        idxs = self.cells[key]["group_indexes"]
        sub = self.df.loc[idxs].copy()

        self.editor_rows = []
        rownum = 0
        for df_index, row in sub.iterrows():
            plant = row.get("PLANT","")

            ttk.Label(self.sub_frame, text=plant, width=PLANT_COL_WIDTH_CH, wraplength=RIGHT_TEXT_WRAP,
                      justify="center", anchor="center").grid(
                row=rownum, column=0, padx=2, pady=2, sticky="w"
            )

            def is_on(v):
                return str(v).strip().lower() in {"1","true","x","✓","si","sí"}

            v_r = tk.IntVar(value=1 if is_on(row.get("Received","")) else 0)
            v_s = tk.IntVar(value=1 if is_on(row.get("Scanned","")) else 0)
            v_p = tk.IntVar(value=1 if is_on(row.get("Pending Receipt","")) else 0)

            def refresh_state(vr=v_r, vs=v_s, vp=v_p, dfrow=row, df_index=df_index):
                temp = {
                    "Received": "1" if vr.get()==1 else "",
                    "Scanned":  "1" if vs.get()==1 else "",
                    "Pending Receipt": "1" if vp.get()==1 else "",
                    "RAP PERIOD END": dfrow.get("RAP PERIOD END","")
                }
                _ = derive_status_per_row(pd.Series(temp))
                self._dirty_indices.add(df_index)
                self._refresh_selected_cell_summary()

            def on_toggle_r(vr=v_r, vp=v_p, *args):
                if vr.get() == 1 and vp.get() == 1:
                    vp.set(0)
                refresh_state()

            def on_toggle_pr(vr=v_r, vp=v_p, *args):
                if vp.get() == 1 and vr.get() == 1:
                    vr.set(0)
                refresh_state()

            def on_toggle_s(*args):
                refresh_state()

            # Checkbuttons con su texto dentro (alineación limpia)
            chk_r = ttk.Checkbutton(self.sub_frame, text="R",  variable=v_r, command=on_toggle_r)
            chk_s = ttk.Checkbutton(self.sub_frame, text="S",  variable=v_s, command=on_toggle_s)
            chk_p = ttk.Checkbutton(self.sub_frame, text="PR", variable=v_p, command=on_toggle_pr)

            chk_r.grid(row=rownum, column=1, padx=(4,4), sticky="n")
            chk_s.grid(row=rownum, column=2, padx=(4,4), sticky="n")
            chk_p.grid(row=rownum, column=3, padx=(4,4), sticky="n")

            self.editor_rows.append({"df_index": df_index, "v_r": v_r, "v_s": v_s, "v_p": v_p})
            rownum += 1

        # siguiente fila libre del editor
        self._editor_next_row = rownum + 1
        self._build_global_totals_panel(self.sub_frame)
        self._update_global_table_inline()

    def _refresh_selected_cell_summary(self):
        if not getattr(self, "editor_rows", None) or not self.current_group_key:
            return

        for er in self.editor_rows:
            idx = er["df_index"]
            r = "1" if er["v_r"].get()==1 else ""
            s = "1" if er["v_s"].get()==1 else ""
            p = "1" if er["v_p"].get()==1 else ""
            if r == "1" and p == "1":
                p = ""
            if p == "1" and r == "1":
                r = ""

            self.df.at[idx, "Received"] = r
            self.df.at[idx, "Scanned"]  = s
            self.df.at[idx, "Pending Receipt"] = p
            deriv = compute_persisted_fields(r, s, p, self.df.at[idx, "RAP PERIOD END"])
            self.df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
            self.df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]

        key = self.current_group_key
        if key in self.cells:
            info = self.cells[key]
            idxs = info["group_indexes"]
            sub = self.df.loc[idxs].copy()
            sub["__state__"] = sub.apply(derive_status_per_row, axis=1)
            _, bg, lines = self._cell_summary_lines(sub, key)

            widget = info["widget"]
            if isinstance(widget, tk.Label):
                widget.configure(text="\n".join([ln for ln in lines if ln]), bg=bg)
            else:
                widget.update_idletasks()
                widget.delete("all")
                z1 = _lighten(bg, 0.35)
                z2 = _lighten(bg, 0.55)
                h = int(widget.winfo_height() or 90)
                if h <= 1: h = 90
                n = max(3, len(lines))
                stripe_h = int(h / n)
                for k in range(n):
                    color = z1 if k % 2 == 0 else z2
                    widget.create_rectangle(0, k*stripe_h, 1000, (k+1)*stripe_h, fill=color, width=0)
                y = 12
                for ln in lines:
                    widget.create_text(110, y, text=ln, anchor="n", width=200, justify="center")
                    y += stripe_h

        self._update_global_table_inline()

    def _commit_editor_changes_to_df(self):
        if not getattr(self, "editor_rows", None) or not self.current_group_key:
            return

        for er in self.editor_rows:
            idx = er["df_index"]
            r = "1" if er["v_r"].get()==1 else ""
            s = "1" if er["v_s"].get()==1 else ""
            p = "1" if er["v_p"].get()==1 else ""

            if r == "1" and p == "1":
                p = ""
            if p == "1" and r == "1":
                r = ""

            self.df.at[idx, "Received"] = r
            self.df.at[idx, "Scanned"]  = s
            self.df.at[idx, "Pending Receipt"] = p

            deriv = compute_persisted_fields(r, s, p, self.df.at[idx, "RAP PERIOD END"])
            self.df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
            self.df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]

            self._dirty_indices.add(idx)

        self._refresh_selected_cell_summary()

    # ---------- ACCIONES MASIVAS ----------
    def _apply_state_to_group(self, key: tuple, mode: str):
        info = self.cells.get(key)
        if not info: return
        idxs = info["group_indexes"]
        for idx in idxs:
            if mode == "R":
                r, s, p = "1", self.df.at[idx, "Scanned"], ""
            elif mode == "S":
                r, s, p = self.df.at[idx, "Received"], "1", self.df.at[idx, "Pending Receipt"]
            else:  # "PR"
                r, s, p = "", self.df.at[idx, "Scanned"], "1"

            if r == "1" and p == "1":
                p = ""
            if p == "1" and r == "1":
                r = ""

            self.df.at[idx, "Received"] = r
            self.df.at[idx, "Scanned"]  = s
            self.df.at[idx, "Pending Receipt"] = p

            deriv = compute_persisted_fields(r, s, p, self.df.at[idx, "RAP PERIOD END"])
            self.df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
            self.df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]

            self._dirty_indices.add(idx)

    def _bulk_apply(self, mode: str):
        targets = self.selected_keys.copy() if self.selected_keys else ({self.current_group_key} if self.current_group_key else set())
        if not targets:
            return
        for k in targets:
            self._apply_state_to_group(k, mode)
            if k in self.cells:
                info = self.cells[k]
                idxs = info["group_indexes"]
                sub = self.df.loc[idxs].copy()
                sub["__state__"] = sub.apply(derive_status_per_row, axis=1)
                _, bg, lines = self._cell_summary_lines(sub, k)
                w = info["widget"]
                if isinstance(w, tk.Label):
                    w.configure(text="\n".join([ln for ln in lines if ln]), bg=bg)
                else:
                    w.update_idletasks()
                    w.delete("all")
                    z1 = _lighten(bg, 0.35); z2 = _lighten(bg, 0.55)
                    h = int(w.winfo_height() or 90); h = 90 if h<=1 else h
                    n = max(3, len(lines)); stripe_h = int(h/n)
                    for kk in range(n):
                        color = z1 if kk % 2 == 0 else z2
                        w.create_rectangle(0, kk*stripe_h, 1000, (kk+1)*stripe_h, fill=color, width=0)
                    y = 12
                    for ln in lines:
                        w.create_text(110, y, text=ln, anchor="n", width=200, justify="center"); y += stripe_h

        if self.current_group_key:
            self._load_group_in_editor(self.current_group_key)

    def _bulk_clear(self):
        targets = self.selected_keys.copy() if self.selected_keys else ({self.current_group_key} if self.current_group_key else set())
        if not targets:
            return
        for k in targets:
            info = self.cells.get(k)
            if not info: continue
            idxs = info["group_indexes"]
            for idx in idxs:
                self.df.at[idx, "Received"] = ""
                self.df.at[idx, "Scanned"]  = ""
                self.df.at[idx, "Pending Receipt"] = ""
                deriv = compute_persisted_fields("", "", "", self.df.at[idx, "RAP PERIOD END"])
                self.df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
                self.df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                self._dirty_indices.add(idx)

            sub = self.df.loc[idxs].copy()
            sub["__state__"] = sub.apply(derive_status_per_row, axis=1)
            _, bg, lines = self._cell_summary_lines(sub, k)
            w = info["widget"]
            if isinstance(w, tk.Label):
                w.configure(text="\n".join([ln for ln in lines if ln]), bg=bg)
            else:
                w.update_idletasks()
                w.delete("all")
                z1 = _lighten(bg, 0.35); z2 = _lighten(bg, 0.55)
                h = int(w.winfo_height() or 90); h = 90 if h<=1 else h
                n = max(3, len(lines)); stripe_h = int(h/n)
                for kk in range(n):
                    color = z1 if kk % 2 == 0 else z2
                    w.create_rectangle(0, kk*stripe_h, 1000, (kk+1)*stripe_h, fill=color, width=0)
                y = 12
                for ln in lines:
                    w.create_text(110, y, text=ln, anchor="n", width=200, justify="center"); y += stripe_h

        if self.current_group_key:
            self._load_group_in_editor(self.current_group_key)

    # ---------- GUARDAR ----------
    def _toast(self, text: str, ms: int = 5000, fg: str = None):
        toast = tk.Toplevel(self)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        frm = ttk.Frame(toast, padding=(10,6))
        frm.pack(fill="both", expand=True)
        lbl = ttk.Label(frm, text=text)
        if fg:
            try:
                lbl.configure(foreground=fg)
            except Exception:
                pass
        lbl.pack()
        self.update_idletasks()
        x = self.winfo_x() + self.winfo_width() - 420
        y = self.winfo_y() + 20
        toast.geometry(f"400x40+{x}+{y}")
        toast.after(ms, toast.destroy)

    def save_to_excel(self):
        self._toast(f"Guardando: {self.xlsx_path}", ms=2500, fg="#1f4e79")

        self._commit_editor_changes_to_df()

        now = datetime.now().strftime(NOW_FMT)
        if "Updated on" not in self.df.columns:
            self.df["Updated on"] = ""
        for idx in sorted(self._dirty_indices):
            if idx in self.df.index:
                self.df.at[idx, "Updated on"] = now

        try:
            df_to_write = self.df.copy()
            for col in ["Received","Scanned","Pending Receipt","Received & Scanned","Pending > 1 Month"]:
                if col in df_to_write.columns:
                    df_to_write[col] = (
                        df_to_write[col].astype(str)
                                        .str.strip()
                                        .replace({"0": "", "nan": ""})
                                        .fillna("")
                    )
            write_excel_table(df_to_write, self.xlsx_path, self.sheet, self.table)
            self._dirty_indices.clear()
        except PermissionError:
            messagebox.showerror("Archivo en uso", "Cierra el Excel y vuelve a intentar.")
        except Exception as e:
            messagebox.showerror("Error al guardar", str(e))

# ---------- MAIN ----------
if __name__ == "__main__":
    if not os.path.exists(XLSX_PATH):
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("No encontrado", f"No existe:\n{XLSX_PATH}")
        root.destroy()
    else:
        app = MatrixApp(XLSX_PATH, SHEET_NAME, TABLE_NAME)
        app.mainloop()
