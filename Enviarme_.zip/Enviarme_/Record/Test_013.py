# app_matriz_streamlit_full.py
# ---------------------------------------------------------
# Réplica Streamlit de matriz_gui_excel.py (UI de la captura)
# - Toolbar: ciclo, filtro por estado, botones masivos (R/S/PR/Clear)
# - Leyenda de colores
# - Matriz coloreada (ID en columnas, Annex en filas) con checkbox de selección
# - Panel derecho con detalle del grupo y editor por planta (AgGrid)
# - Totales globales de la vista
# - Escritura segura a Excel manteniendo la Excel Table
# - Fix de índices mediante columna técnica _RIDX
# ---------------------------------------------------------

import os
from datetime import datetime
from typing import Tuple, List, Dict, Optional

import pandas as pd
import streamlit as st
from st_aggrid import AgGrid, GridOptionsBuilder

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# ===================== CONFIG =====================
XLSX_PATH  = "Data_record.xlsx"  # ajusta si es necesario
SHEET_NAME = "Records_"
TABLE_NAME = "DB_Records"

SLC_ANNEX_SHEET        = "Slc_Annex_"
SLC_ANNEX_TABLE        = "Slc_Annex"          # ANNEX, DESCRIPTION, RESPONSIBLE AREA

SLC_INFO_SHEET         = "Slc_Info_"
SLC_INFO_TABLE         = "Slc_Info"           # ID, API, PRODUCT, CODES/CODE, CICLE, RAP PERIOD START, RAP PERIOD END...

SLC_DISTRIBUTION_SHEET = "Slc_Distribution_"  # opcional
SLC_DISTRIBUTION_TABLE = "Slc_Distribution"   # opcional

DATE_FMT = "%d/%m/%Y"
NOW_FMT  = "%Y-%m-%d %H:%M:%S"

COLORS = {
    "Received & Scanned": "#c6efce",
    "Received": "#e2f0d9",
    "Scanned": "#ddebf7",
    "Pending Receipt": "#fff2cc",
    "Pending > 1 Month": "#f8cbad",
    "": "#ffffff",
}
PRIORITY = ["Pending > 1 Month", "Pending Receipt",
            "Received & Scanned", "Received", "Scanned", ""]

# ===================== HELPERS =====================
def _norm_id(x) -> str:
    s = str(x).strip()
    s2 = s.lstrip("0")
    return s if s2 == "" else s2

def _norm_annex(x) -> str:
    s = str(x).strip()
    if s.isdigit():
        s2 = s.lstrip("0")
        return s if s2 == "" else s2
    return s

def _safe_upper_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().upper() for c in df.columns]
    return df

def _nc(name: str) -> str:
    return "".join(ch for ch in str(name).upper() if ch.isalnum() or ch == "_")

def _get_val(d: Dict[str, str], *keys: str) -> str:
    for k in keys:
        if k in d:
            return d.get(k, "")
    return ""

def parse_date_ddmmyyyy(s: str) -> Optional[datetime]:
    s = (s or "").strip()
    if not s: return None
    for fmt in (DATE_FMT, "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    return None

def _fmt_date_dd_mmm(d: Optional[datetime]) -> str:
    return "" if not d else d.strftime("%d-%b-%Y")

def _row_pr_overdue(row: pd.Series) -> bool:
    rap = parse_date_ddmmyyyy(str(row.get("RAP PERIOD END", "")).strip())
    if not rap:
        return False
    return (datetime.today().date() - rap.date()).days > 30

def derive_status_per_row(row: pd.Series) -> str:
    def _is_on(v: str) -> bool:
        s = str(v).strip().lower()
        return s in ("1", "true", "sí", "si", "x", "✓")
    r = _is_on(row.get("Received", ""))
    s = _is_on(row.get("Scanned", ""))
    pr = _is_on(row.get("Pending Receipt", ""))

    if r:
        pr = False

    if pr:
        return "Pending > 1 Month" if _row_pr_overdue(row) else "Pending Receipt"
    if r and s: return "Received & Scanned"
    if r: return "Received"
    if s: return "Scanned"
    return ""

def compute_persisted_fields(received: str, scanned: str, pending_r: str, rap_end: str) -> Dict[str, str]:
    rs = "1" if (received == "1" and scanned == "1") else ""
    pgt = ""
    if pending_r == "1":
        rap = parse_date_ddmmyyyy(rap_end)
        overdue = rap is not None and (datetime.today().date() - rap.date()).days > 30
        pgt = "1" if overdue else ""
    return {"Received & Scanned": rs, "Pending > 1 Month": pgt}

def summarize_group_status(states: List[str]) -> str:
    for state in PRIORITY:
        if state and state in states:
            return state
    return ""

# ===================== EXCEL I/O =====================
def _excel_table_bounds(ws, table_name: str) -> Tuple[int, int, int, int]:
    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = tables[table_name]
    else:
        found = [tbl for tbl in tables if getattr(tbl, "name", None) == table_name]
        if not found:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = found[0]
    ref = t.ref
    min_row = ws[ref][0][0].row
    min_col = ws[ref][0][0].column
    max_row = ws[ref][-1][-1].row
    max_col = ws[ref][-1][-1].column
    return min_row, min_col, max_row, max_col

def read_excel_table(xlsx_path: str, sheet_name: str, table_name: str) -> pd.DataFrame:
    wb = load_workbook(xlsx_path, data_only=True, read_only=False)
    if sheet_name not in wb.sheetnames:
        wb.close(); raise ValueError(f"No existe la hoja '{sheet_name}'")
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)
    data = [list(r) for r in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2, values_only=True)]
    wb.close()
    if not data: return pd.DataFrame()
    headers = [str(h).strip() if h is not None else "" for h in data[0]]
    df = pd.DataFrame(data[1:], columns=headers).fillna("").astype(str)
    return df

def write_excel_table(df: pd.DataFrame, xlsx_path: str, sheet_name: str, table_name: str):
    if not os.path.exists(xlsx_path):
        raise FileNotFoundError(xlsx_path)
    wb = load_workbook(xlsx_path)
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)

    headers = list(df.columns)
    n_rows = len(df) + 1
    n_cols = len(headers)

    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = tables[table_name]
    else:
        found = [t for t in tables if getattr(t, "name", None) == table_name]
        if not found:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = found[0]

    end_row = r1 + n_rows - 1
    end_col = c1 + n_cols - 1
    table.ref = f"{get_column_letter(c1)}{r1}:{get_column_letter(end_col)}{end_row}"

    for j, val in enumerate(headers, start=c1):
        ws.cell(row=r1, column=j, value=val)

    for rr in range(r1 + 1, r2 + 1):
        for cc in range(c1, c2 + 1):
            ws.cell(row=rr, column=cc, value=None)

    for i in range(len(df)):
        for j in range(n_cols):
            ws.cell(row=r1 + 1 + i, column=c1 + j, value=df.iat[i, j])

    wb.save(xlsx_path); wb.close()

# ===================== CARGA INICIAL =====================
@st.cache_data(show_spinner=False)
def load_all():
    df = read_excel_table(XLSX_PATH, SHEET_NAME, TABLE_NAME)
    for col in ["ID","ANNEX","PLANT","CICLE","Received","Scanned","Pending Receipt","RAP PERIOD END","Updated on"]:
        if col not in df.columns:
            df[col] = ""

    annex_desc, annex_resp = {}, {}
    try:
        df_cat = _safe_upper_columns(read_excel_table(XLSX_PATH, SLC_ANNEX_SHEET, SLC_ANNEX_TABLE))
        cols_norm = {_nc(c): c for c in df_cat.columns}
        annex_col = cols_norm.get("ANNEX")
        desc_col  = cols_norm.get("DESCRIPTION")
        resp_col  = (cols_norm.get("RESPONSIBLEAREA") or cols_norm.get("RESPONSIBLE_AREA")
                     or cols_norm.get("RESPAREA") or cols_norm.get("RESPONSIBLE"))
        for _, r in df_cat.iterrows():
            key = _norm_annex(r.get(annex_col, "") if annex_col else "")
            if not key: continue
            if desc_col: annex_desc[key] = str(r.get(desc_col, "")).strip()
            if resp_col: annex_resp[key] = str(r.get(resp_col, "")).strip()
    except Exception:
        pass

    info_rows_by_id: Dict[str, List[Dict[str, str]]] = {}
    def _ingest_info_df(df_src: pd.DataFrame):
        dfi = _safe_upper_columns(df_src).fillna("")
        if "ID" not in dfi.columns: return
        for _, r in dfi.iterrows():
            rid = _norm_id(r.get("ID",""))
            if not rid: continue
            info_rows_by_id.setdefault(rid, []).append({k: str(r.get(k,"")).strip() for k in dfi.columns})
    try:
        df_info_tbl = read_excel_table(XLSX_PATH, SLC_INFO_SHEET, SLC_INFO_TABLE)
        if not df_info_tbl.empty: _ingest_info_df(df_info_tbl)
    except Exception: pass
    if not info_rows_by_id:
        try:
            df_sheet = pd.read_excel(XLSX_PATH, sheet_name=SLC_INFO_SHEET, dtype=str)
            _ingest_info_df(df_sheet)
        except Exception: pass

    # distribución opcional (no usada directo en UI)
    try:
        df_dist_tbl = read_excel_table(XLSX_PATH, SLC_DISTRIBUTION_SHEET, SLC_DISTRIBUTION_TABLE)
        df_distribution = _safe_upper_columns(df_dist_tbl)
    except Exception:
        try:
            df_distribution = _safe_upper_columns(
                pd.read_excel(XLSX_PATH, sheet_name=SLC_DISTRIBUTION_SHEET, dtype=str).fillna("")
            )
        except Exception:
            df_distribution = pd.DataFrame()

    return df, annex_desc, annex_resp, info_rows_by_id, df_distribution

# ===================== FUNCIONES UI =====================
def pick_info_row(info_rows_by_id: Dict[str, List[Dict[str,str]]], id_str: str, anex: str, cicle_selected: str):
    rid = _norm_id(id_str)
    rows = info_rows_by_id.get(rid, []) or info_rows_by_id.get(str(id_str).strip(), [])
    if not rows: return None
    for r in rows:
        if _norm_annex(r.get("ANNEX","")) == _norm_annex(anex): return r
    for r in rows:
        if str(r.get("CICLE","")).strip() == str(cicle_selected).strip(): return r
    return rows[0]

def header_text_for_id(info_rows_by_id, pid: str, cicle_selected: str) -> str:
    rid = _norm_id(pid)
    rows = info_rows_by_id.get(rid, []) or info_rows_by_id.get(str(pid).strip(), [])
    chosen = None
    if rows:
        for r in rows:
            if str(r.get("CICLE", "")).strip() == str(cicle_selected).strip():
                chosen = r; break
        if not chosen: chosen = rows[0]
    api = _get_val(chosen or {}, "API")
    d_s = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD START"))
    d_e = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD END"))
    s_fmt = _fmt_date_dd_mmm(d_s); e_fmt = _fmt_date_dd_mmm(d_e)
    rng = f"{s_fmt} al {e_fmt}" if (s_fmt or e_fmt) else ""
    parts = [p for p in [api, rng] if p]
    return "\n".join(parts)

def cell_summary_lines(grp: pd.DataFrame, key: tuple, annex_resp: Dict[str,str]) -> (str, str, List[str]):
    states = grp["__state__"].tolist()
    group_state = summarize_group_status(states)
    bg = COLORS.get(group_state, "#ffffff")
    lines = [group_state if group_state else ""]
    resp = annex_resp.get(_norm_annex(key[1]), "")
    if resp: lines.append(f"Responsible Area: {resp}")
    for _, r in grp.iterrows():
        plant = (r.get("PLANT","") or "").strip()
        stx = r["__state__"]
        mini = "!!" if stx == "Pending > 1 Month" else "!" if stx == "Pending Receipt" else \
               "✓✓" if stx == "Received & Scanned" else "✓" if stx == "Received" else \
               "S" if stx == "Scanned" else "-"
        lines.append(f"{plant}: {mini}")
    return group_state, bg, lines

def color_card(text: str, bg: str):
    st.markdown(
        f"""
        <div style="
            background:{bg};
            border:1px solid #9eb6d8;
            border-radius:8px;
            padding:10px;
            min-height:84px;
            font-size:13px;
            white-space:pre-wrap;
            text-align:center;
        ">{text}</div>
        """,
        unsafe_allow_html=True
    )

def totals_panel(df_view: pd.DataFrame, ids: List[str], anexos: List[str]) -> None:
    existing_groups = received_groups = scanned_groups = pending_groups = 0
    for pid in ids:
        for anex in anexos:
            grp = df_view[(df_view["ID"].astype(str).map(_norm_id) == _norm_id(pid)) &
                          (df_view["ANNEX"].astype(str).map(_norm_annex) == _norm_annex(anex))]
            if grp.empty: continue
            existing_groups += 1
            state = summarize_group_status(grp["__state__"].tolist())
            if state in ("Received", "Received & Scanned"): received_groups += 1
            if state in ("Scanned", "Received & Scanned"): scanned_groups += 1
            if state.startswith("Pending"): pending_groups += 1

    def pct(n, d): return f"{(n/d*100):.1f}%" if d>0 else "0.0%"

    st.markdown("**All files in current view:** " + str(existing_groups))
    c1, c2, c3 = st.columns(3)
    with c1: st.metric("Received", f"{received_groups}", pct(received_groups, existing_groups))
    with c2: st.metric("Scanned", f"{scanned_groups}", pct(scanned_groups, existing_groups))
    with c3: st.metric("Pending Receipt", f"{pending_groups}", pct(pending_groups, existing_groups))

# ===================== APP =====================
def main():
    st.set_page_config(page_title="AERR | Annex Tracking (Streamlit)", layout="wide")
    st.title("AERR | Annex Tracking System")

    try:
        df, annex_desc, annex_resp, info_rows_by_id, _ = load_all()
    except Exception as e:
        st.error(f"Error al leer Excel: {e}")
        st.stop()

    # Derivar estado
    df["__state__"] = df.apply(derive_status_per_row, axis=1)

    # ---- Sidebar / Toolbar ----
    st.sidebar.header("Filtros")
    cycles = sorted(df["CICLE"].astype(str).unique(), key=lambda x: (len(x), x))
    cicle_selected = st.sidebar.selectbox("Ciclo", cycles, index=0 if cycles else None)

    state_options = ["(All)", "Received & Scanned", "Received", "Scanned", "Pending Receipt", "Pending > 1 Month"]
    state_filter = st.sidebar.selectbox("Filter by status", state_options, index=0)

    # región de acciones masivas
    st.sidebar.header("Acciones masivas")
    btn_r  = st.sidebar.button("Set Received")
    btn_s  = st.sidebar.button("Set Scanned")
    btn_pr = st.sidebar.button("Set Pending")
    btn_cl = st.sidebar.button("Clear Checks")
    st.sidebar.markdown("---")
    btn_save = st.sidebar.button("💾 Guardar a Excel")

    # ---- Datos filtrados para la vista ----
    view = df[df["CICLE"].astype(str) == cicle_selected].copy()
    view["__state__"] = view.apply(derive_status_per_row, axis=1)
    if state_filter != "(All)":
        view = view[view["__state__"] == state_filter]

    ids = list(dict.fromkeys([_norm_id(x) for x in view["ID"].astype(str).tolist()]))
    try:
        anexos = sorted({int(_norm_annex(x)) for x in view["ANNEX"].astype(str).tolist() if str(x).strip().isdigit()})
        anexos = [str(a) for a in anexos]
    except Exception:
        anexos = list(dict.fromkeys([_norm_annex(x) for x in view["ANNEX"].astype(str).tolist()]))
    if not anexos: anexos = [str(i) for i in range(1,19)]
    anexos = list(dict.fromkeys([_norm_annex(a) for a in anexos]))

    # estado de selección y grupo actual
    st.session_state.setdefault("selected_keys", set())
    st.session_state.setdefault("current_key", None)

    # ====== Layout principal ======
    left, right = st.columns([2.5, 1.5])

    # ====== MATRIZ IZQUIERDA ======
    with left:
        st.subheader("Matriz")

        # Encabezado de columnas (IDs con info API + rango RAP)
        hdr_cols = st.columns([1] + [1 for _ in ids])
        hdr_cols[0].markdown("**Annex**")
        for j, pid in enumerate(ids, start=1):
            header_txt = header_text_for_id(info_rows_by_id, pid, cicle_selected)
            hdr_cols[j].markdown(
                f"<div style='border:1px solid #ccc;border-radius:6px;padding:6px;white-space:pre-wrap;text-align:center'>{header_txt or pid}</div>",
                unsafe_allow_html=True
            )

        # Leyenda
        legend = st.columns(5)
        for i, s in enumerate(["Received & Scanned","Received","Scanned","Pending Receipt","Pending > 1 Month"]):
            with legend[i]:
                st.markdown(f"<div style='display:inline-block;width:14px;height:14px;background:{COLORS[s]};border:1px solid #999;vertical-align:middle;margin-right:6px'></div><span>{s}</span>", unsafe_allow_html=True)

        st.markdown("---")

        # Filas por Annex
        for an in anexos:
            row_cols = st.columns([1] + [1 for _ in ids])
            row_cols[0].markdown(f"**{an}**")
            for j, pid in enumerate(ids, start=1):
                grp = view[(view["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                           (view["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(an))]
                key = (str(pid), str(an))
                if grp.empty:
                    row_cols[j].markdown(
                        "<div style='background:#eeeeee;border:1px dashed #bbb;border-radius:6px;height:84px'></div>",
                        unsafe_allow_html=True
                    )
                    continue

                _, bg, lines = cell_summary_lines(grp, key, annex_resp)
                txt = "\n".join([ln for ln in lines if ln])

                with row_cols[j]:
                    color_card(txt, bg)
                    c1, c2 = st.columns([1,1])
                    with c1:
                        # checkbox de selección múltiple (para acciones masivas)
                        sel_key = f"sel_{pid}_{an}"
                        checked = st.checkbox("Sel", key=sel_key, value=((pid,an) in st.session_state["selected_keys"]))
                        if checked:
                            st.session_state["selected_keys"].add((pid,an))
                        else:
                            st.session_state["selected_keys"].discard((pid,an))
                    with c2:
                        if st.button("Editar", key=f"btn_{pid}_{an}", use_container_width=True):
                            st.session_state["current_key"] = (pid, an)

        st.divider()
        st.subheader("Totales de la vista")
        totals_panel(view, ids, anexos)

    # ====== ACCIONES MASIVAS SOBRE SELECCIÓN ======
    def _apply_bulk(mode: str):
        targets = list(st.session_state["selected_keys"])
        if not targets: return
        for pid, anex in targets:
            idxs = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                      (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))].index
            for ridx in idxs:
                if mode == "R":
                    r, s, p = "1", df.loc[ridx, "Scanned"], ""
                elif mode == "S":
                    r, s, p = df.loc[ridx, "Received"], "1", df.loc[ridx, "Pending Receipt"]
                elif mode == "PR":
                    r, s, p = "", df.loc[ridx, "Scanned"], "1"
                else:  # CLEAR
                    r, s, p = "", "", ""
                # exclusión mutua R/PR
                if r == "1" and p == "1": p = ""
                if p == "1" and r == "1": r = ""
                df.loc[ridx, "Received"] = r
                df.loc[ridx, "Scanned"]  = s
                df.loc[ridx, "Pending Receipt"] = p
                deriv = compute_persisted_fields(r, s, p, df.loc[ridx, "RAP PERIOD END"])
                df.loc[ridx, "Received & Scanned"] = deriv["Received & Scanned"]
                df.loc[ridx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                df.loc[ridx, "Updated on"] = datetime.now().strftime(NOW_FMT)

    if btn_r:  _apply_bulk("R");  st.success("Aplicado: Received"); st.experimental_rerun()
    if btn_s:  _apply_bulk("S");  st.success("Aplicado: Scanned");  st.experimental_rerun()
    if btn_pr: _apply_bulk("PR"); st.success("Aplicado: Pending");  st.experimental_rerun()
    if btn_cl: _apply_bulk("CLR"); st.success("Checks limpiados");  st.experimental_rerun()

    # ====== PANEL DERECHO: DETALLE/EDICIÓN ======
    with right:
        st.subheader("Detalle / Edición")
        cur = st.session_state["current_key"]

        if not cur:
            st.info("Selecciona un grupo (ID, ANNEX) con **Editar** para ver/editar detalles.")
        else:
            id_, anex = cur
            st.markdown(f"**ANNEX={anex}**")
            st.caption(annex_desc.get(_norm_annex(anex), ""))

            info = pick_info_row(info_rows_by_id, id_, anex, cicle_selected) or {}
            date_keys = {
                "ANNEX DEADLINE (8 WEEKS / 56 DAYS)",
                "REPORT ISSUANCE (90 DAYS)",
                "DEADLINE FOR SIGNING (120 DAYS)",
            }
            def _fmt_cell(v: str, is_date: bool=False) -> str:
                if not is_date: return v or ""
                d = parse_date_ddmmyyyy(v); return _fmt_date_dd_mmm(d) if d else (v or "")

            info_rows = [
                ("API", info.get("API","")),
                ("PRODUCT", info.get("PRODUCT","")),
                ("CODES", _get_val(info, "CODES", "CODE")),
                ("ANNEX DEADLINE (8 WEEKS / 56 DAYS)", _fmt_cell(info.get("ANNEX DEADLINE (8 WEEKS / 56 DAYS)",""), True)),
                ("REPORT ISSUANCE (90 DAYS)", _fmt_cell(info.get("REPORT ISSUANCE (90 DAYS)",""), True)),
                ("DEADLINE FOR SIGNING (120 DAYS)", _fmt_cell(info.get("DEADLINE FOR SIGNING (120 DAYS)",""), True)),
            ]
            for k, v in info_rows:
                st.markdown(f"**{k}:** {v}")

            idxs = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(id_)) &
                      (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))].index
            sub = df.loc[idxs, ["PLANT","Received","Scanned","Pending Receipt","RAP PERIOD END"]].copy()

            # FIX índice real
            sub_to_grid = sub.reset_index().rename(columns={"index":"_RIDX"})
            for c in ["Received","Scanned","Pending Receipt"]:
                sub_to_grid[c] = sub_to_grid[c].astype(str).str.strip().isin(["1","true","TRUE","x","X","✓","si","sí"])

            gob = GridOptionsBuilder.from_dataframe(sub_to_grid)
            gob.configure_selection("single", use_checkbox=True)
            for c in ["Received","Scanned","Pending Receipt"]:
                gob.configure_column(c, editable=True)
            gob.configure_column("PLANT", editable=False)
            gob.configure_column("_RIDX", editable=False, hide=True)
            grid_options = gob.build()

            grid = AgGrid(
                sub_to_grid,
                gridOptions=grid_options,
                update_on="MODEL_UPDATED",  # reemplaza GridUpdateMode (deprecated)
                allow_unsafe_jscode=False,
                fit_columns_on_grid_load=True,
                height=320,
                theme="alpine",
            )
            edited_df = pd.DataFrame(grid["data"])

            c1, c2, c3, c4 = st.columns(4)
            apply_edit = c1.button("Aplicar cambios")
            set_recv   = c2.button("Set Received (grupo)")
            set_scan   = c3.button("Set Scanned (grupo)")
            set_pend   = c4.button("Set Pending (grupo)")

            def persist_row(r):
                ridx = r["_RIDX"]
                rec  = "1" if bool(r["Received"]) else ""
                scn  = "1" if bool(r["Scanned"]) else ""
                pen  = "1" if bool(r["Pending Receipt"]) else ""
                if rec == "1" and pen == "1": pen = ""
                if pen == "1" and rec == "1": rec = ""
                df.loc[ridx, "Received"] = rec
                df.loc[ridx, "Scanned"]  = scn
                df.loc[ridx, "Pending Receipt"] = pen
                deriv = compute_persisted_fields(rec, scn, pen, df.loc[ridx, "RAP PERIOD END"])
                df.loc[ridx, "Received & Scanned"] = deriv["Received & Scanned"]
                df.loc[ridx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                df.loc[ridx, "Updated on"] = datetime.now().strftime(NOW_FMT)

            if apply_edit:
                for _, r in edited_df.iterrows(): persist_row(r)
                st.success("Cambios aplicados al dataset en memoria."); st.experimental_rerun()

            def apply_bulk_group(mode: str):
                for _, r in edited_df.iterrows():
                    ridx = r["_RIDX"]
                    if mode == "R":
                        rec, scn, pen = "1", df.loc[ridx, "Scanned"], ""
                    elif mode == "S":
                        rec, scn, pen = df.loc[ridx, "Received"], "1", df.loc[ridx, "Pending Receipt"]
                    else:  # PR
                        rec, scn, pen = "", df.loc[ridx, "Scanned"], "1"
                    if rec == "1" and pen == "1": pen = ""
                    if pen == "1" and rec == "1": rec = ""
                    df.loc[ridx, "Received"] = rec
                    df.loc[ridx, "Scanned"]  = scn
                    df.loc[ridx, "Pending Receipt"] = pen
                    deriv = compute_persisted_fields(rec, scn, pen, df.loc[ridx, "RAP PERIOD END"])
                    df.loc[ridx, "Received & Scanned"] = deriv["Received & Scanned"]
                    df.loc[ridx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                    df.loc[ridx, "Updated on"] = datetime.now().strftime(NOW_FMT)

            if set_recv: apply_bulk_group("R");  st.success("Marcado como Received (grupo)."); st.experimental_rerun()
            if set_scan: apply_bulk_group("S");  st.success("Marcado como Scanned (grupo).");  st.experimental_rerun()
            if set_pend: apply_bulk_group("PR"); st.success("Marcado como Pending (grupo).");  st.experimental_rerun()

            st.markdown("---")
            if btn_save:
                df_to_write = df.copy()
                for col in ["Received","Scanned","Pending Receipt","Received & Scanned","Pending > 1 Month"]:
                    if col in df_to_write.columns:
                        df_to_write[col] = (
                            df_to_write[col].astype(str).str.strip()
                                        .replace({"0":"", "nan":""}).fillna("")
                        )
                try:
                    write_excel_table(df_to_write, XLSX_PATH, SHEET_NAME, TABLE_NAME)
                    st.success(f"Datos guardados en {XLSX_PATH}")
                    load_all.clear()
                except PermissionError:
                    st.error("Archivo en uso. Cierra el Excel y vuelve a intentar.")
                except Exception as e:
                    st.error(f"Error al guardar: {e}")

if __name__ == "__main__":
    main()
streamlit run C:\Users\Alex-PC\Desktop\python_Pro_Registros\Test_013.py