# matriz_gui_excel_tksheet.py
import os
from datetime import datetime
from typing import Tuple, List, Dict, Optional

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

from tksheet import Sheet
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# --- CONFIG ---
XLSX_PATH  = "Data_record.xlsx"
SHEET_NAME = "Records_"
TABLE_NAME = "DB_Records"

SLC_ANNEX_SHEET        = "Slc_Annex_"
SLC_ANNEX_TABLE        = "Slc_Annex"

SLC_INFO_SHEET         = "Slc_Info_"
SLC_INFO_TABLE         = "Slc_Info"

SLC_DISTRIBUTION_SHEET = "Slc_Distribution_"
SLC_DISTRIBUTION_TABLE = "Slc_Distribution"

DATE_FMT   = "%d/%m/%Y"

COLORS = {
    "Received & Scanned": "#c6efce",
    "Received": "#e2f0d9",
    "Scanned": "#ddebf7",
    "Pending Receipt": "#fff2cc",
    "Pending > 1 Month": "#f8cbad",
    "": "#ffffff",
}
PRIORITY = ["Pending > 1 Month", "Pending Receipt",
            "Received & Scanned", "Received", "Scanned", ""]

NOW_FMT = "%Y-%m-%d %H:%M:%S"


# ---------- HELPERS ----------
def _norm_id(x) -> str:
    s = str(x).strip()
    s2 = s.lstrip("0")
    return s if s2 == "" else s2

def _norm_annex(x) -> str:
    s = str(x).strip()
    if s.isdigit():
        s2 = s.lstrip("0")
        return s if s2 == "" else s2
    return s

def _safe_upper_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().upper() for c in df.columns]
    return df

def _nc(name: str) -> str:
    return "".join(ch for ch in str(name).upper() if ch.isalnum() or ch == "_")

def _get_val(d: Dict[str, str], *keys: str) -> str:
    for k in keys:
        if k in d:
            return d.get(k, "")
    return ""

def _fmt_date_dd_mmm(d: Optional[datetime]) -> str:
    if not d: return ""
    return d.strftime("%d-%b-%Y")

def parse_date_ddmmyyyy(s: str) -> Optional[datetime]:
    s = (s or "").strip()
    if not s: return None
    for fmt in (DATE_FMT, "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%y", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    return None

def _lighten(hex_color: str, factor: float) -> str:
    hex_color = hex_color.lstrip("#")
    if len(hex_color) != 6:
        return "#f5f5f5"
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    r = int(r + (255 - r) * factor)
    g = int(g + (255 - g) * factor)
    b = int(b + (255 - b) * factor)
    return f"#{r:02x}{g:02x}{b:02x}"

# ---------- UTILIDADES EXCEL ----------
def _excel_table_bounds(ws, table_name: str) -> Tuple[int, int, int, int]:
    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = tables[table_name]
    else:
        found = [tbl for tbl in tables if getattr(tbl, "name", None) == table_name]
        if not found:
            raise ValueError(f"No se encontró la tabla '{table_name}' en '{ws.title}'")
        t = found[0]
    ref = t.ref
    min_row = ws[ref][0][0].row
    min_col = ws[ref][0][0].column
    max_row = ws[ref][-1][-1].row
    max_col = ws[ref][-1][-1].column
    return min_row, min_col, max_row, max_col

def read_excel_table(xlsx_path: str, sheet_name: str, table_name: str) -> pd.DataFrame:
    wb = load_workbook(xlsx_path, data_only=True, read_only=False)
    if sheet_name not in wb.sheetnames:
        wb.close(); raise ValueError(f"No existe la hoja '{sheet_name}'")
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)
    data = [list(r) for r in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2, values_only=True)]
    wb.close()
    if not data: return pd.DataFrame()
    headers = [str(h).strip() if h is not None else "" for h in data[0]]
    df = pd.DataFrame(data[1:], columns=headers)
    df = df.fillna("").astype(str)
    return df

def write_excel_table(df: pd.DataFrame, xlsx_path: str, sheet_name: str, table_name: str):
    if not os.path.exists(xlsx_path):
        raise FileNotFoundError(xlsx_path)
    wb = load_workbook(xlsx_path)
    ws = wb[sheet_name]
    r1, c1, r2, c2 = _excel_table_bounds(ws, table_name)

    headers = list(df.columns)
    n_rows = len(df) + 1
    n_cols = len(headers)

    tables = getattr(ws, "tables", None) or ws._tables
    if isinstance(tables, dict):
        if table_name not in tables:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = tables[table_name]
    else:
        found = [t for t in tables if getattr(t, "name", None) == table_name]
        if not found:
            wb.close(); raise ValueError(f"No se encontró la tabla '{table_name}' en '{sheet_name}'")
        table = found[0]

    end_row = r1 + n_rows - 1
    end_col = c1 + n_cols - 1
    table.ref = f"{get_column_letter(c1)}{r1}:{get_column_letter(end_col)}{end_row}"

    for j, val in enumerate(headers, start=c1):
        ws.cell(row=r1, column=j, value=val)

    for rr in range(r1 + 1, r2 + 1):
        for cc in range(c1, c2 + 1):
            ws.cell(row=rr, column=cc, value=None)

    for i in range(len(df)):
        for j in range(n_cols):
            ws.cell(row=r1 + 1 + i, column=c1 + j, value=df.iat[i, j])

    wb.save(xlsx_path); wb.close()

# ---------- LÓGICA ESTADOS ----------
def _row_pr_overdue(row: pd.Series) -> bool:
    rap = parse_date_ddmmyyyy(str(row.get("RAP PERIOD END", "")).strip())
    if not rap:
        return False
    days_over = (datetime.today().date() - rap.date()).days
    return days_over > 30

def derive_status_per_row(row: pd.Series) -> str:
    def _is_on(v: str) -> bool:
        s = str(v).strip().lower()
        return s in ("1", "true", "sí", "si", "x")
    r = _is_on(row.get("Received", ""))
    s = _is_on(row.get("Scanned", ""))
    pr = _is_on(row.get("Pending Receipt", ""))

    if r:
        pr = False

    if pr:
        return "Pending > 1 Month" if _row_pr_overdue(row) else "Pending Receipt"
    if r and s: return "Received & Scanned"
    if r: return "Received"
    if s: return "Scanned"
    return ""

def compute_persisted_fields(received: str, scanned: str, pending_r: str, rap_end: str) -> Dict[str, str]:
    rs = "1" if (received == "1" and scanned == "1") else ""
    pgt = ""
    if pending_r == "1":
        rap = parse_date_ddmmyyyy(rap_end)
        overdue = rap is not None and (datetime.today().date() - rap.date()).days > 30
        pgt = "1" if overdue else ""
    return {"Received & Scanned": rs, "Pending > 1 Month": pgt}

def summarize_group_status(states: List[str]) -> str:
    for state in PRIORITY:
        if state and state in states:
            return state
    return ""


# ---------- APP ----------
class MatrixApp(tk.Tk):
    def __init__(self, xlsx_path: str, sheet: str, table: str):
        super().__init__()
        self.title("AERR | Annex Tracking System (tksheet)")
        self.geometry("1380x880")

        self.xlsx_path = xlsx_path
        self.sheet = sheet
        self.table = table

        try:
            self.df = read_excel_table(self.xlsx_path, self.sheet, self.table)
        except Exception as e:
            messagebox.showerror("Error al leer Excel", str(e)); self.destroy(); return

        required_cols = ["ID","ANNEX","PLANT","CICLE","Received","Scanned","Pending Receipt","RAP PERIOD END","Updated on"]
        for col in required_cols:
            if col not in self.df.columns:
                self.df[col] = ""

        self._dirty_indices: set[int] = set()

        # ====== Slc_Annex ======
        self.annex_desc: Dict[str, str] = {}
        self.annex_resp: Dict[str, str] = {}
        try:
            df_cat = read_excel_table(self.xlsx_path, SLC_ANNEX_SHEET, SLC_ANNEX_TABLE)
            df_cat = _safe_upper_columns(df_cat)
            cols_norm = {_nc(c): c for c in df_cat.columns}
            annex_col = cols_norm.get("ANNEX")
            desc_col  = cols_norm.get("DESCRIPTION")
            resp_col  = (cols_norm.get("RESPONSIBLEAREA") or cols_norm.get("RESPONSIBLE_AREA")
                         or cols_norm.get("RESPAREA") or cols_norm.get("RESPONSIBLE"))
            for _, r in df_cat.iterrows():
                raw_key = r.get(annex_col, "") if annex_col else ""
                key = _norm_annex(raw_key)
                if not key: continue
                if desc_col: self.annex_desc[key] = str(r.get(desc_col, "")).strip()
                if resp_col: self.annex_resp[key] = str(r.get(resp_col, "")).strip()
        except Exception:
            pass

        # ====== Slc_Info (por ID) ======
        self.info_rows_by_id: Dict[str, List[Dict[str, str]]] = {}

        def _ingest_info_df(df_src: pd.DataFrame):
            df_i = _safe_upper_columns(df_src).fillna("")
            if "ID" not in df_i.columns:
                return
            for _, r in df_i.iterrows():
                rid = _norm_id(r.get("ID", ""))
                if not rid: continue
                row_dict = {k: str(r.get(k, "")).strip() for k in df_i.columns}
                self.info_rows_by_id.setdefault(rid, []).append(row_dict)

        try:
            df_info_tbl = read_excel_table(self.xlsx_path, SLC_INFO_SHEET, SLC_INFO_TABLE)
            if not df_info_tbl.empty:
                _ingest_info_df(df_info_tbl)
        except Exception:
            pass
        if not self.info_rows_by_id:
            try:
                df_sheet = pd.read_excel(self.xlsx_path, sheet_name=SLC_INFO_SHEET, dtype=str)
                _ingest_info_df(df_sheet)
            except Exception:
                pass

        # ====== Slc_Distribution (opcional) ======
        self.df_distribution: pd.DataFrame = pd.DataFrame()
        try:
            df_dist_tbl = read_excel_table(self.xlsx_path, SLC_DISTRIBUTION_SHEET, SLC_DISTRIBUTION_TABLE)
            self.df_distribution = _safe_upper_columns(df_dist_tbl)
        except Exception:
            try:
                self.df_distribution = _safe_upper_columns(
                    pd.read_excel(self.xlsx_path, sheet_name=SLC_DISTRIBUTION_SHEET, dtype=str).fillna("")
                )
            except Exception:
                self.df_distribution = pd.DataFrame()

        # ====== LAYOUT ======
        self.toolbar = ttk.Frame(self); self.toolbar.pack(fill="x", padx=10, pady=(8,4))
        self._build_toolbar(self.toolbar)

        self.legend = ttk.Frame(self); self.legend.pack(fill="x", padx=10, pady=(0,8))
        self._build_legend(self.legend)

        split = ttk.Panedwindow(self, orient="horizontal")
        split.pack(fill="both", expand=True, padx=10, pady=6)

        left_container = ttk.Frame(split)
        split.add(left_container, weight=3)
        self._build_matrix_sheet(left_container)

        right_container = ttk.Frame(split, width=480)
        split.add(right_container, weight=1)
        self._build_editor(right_container)

        self.cells_map: Dict[tuple, Dict] = {}
        self.current_group_key: tuple | None = None

        self.ids: List[str] = []
        self.anexos: List[str] = []
        self.group_exists: Dict[tuple, bool] = {}

        self.bind_all("<Control-s>", lambda e: self.save_to_excel())
        self.render_matrix()

    # --- Selector de mejor fila de Slc_Info ---
    def _pick_info_row(self, id_str: str, anex: str, cicle_selected: str) -> Optional[Dict[str, str]]:
        rid = _norm_id(id_str)
        rows = self.info_rows_by_id.get(rid, []) or self.info_rows_by_id.get(str(id_str).strip(), [])
        if not rows: return None
        for r in rows:
            annex_val = r.get("ANNEX", "")
            if _norm_annex(annex_val) == _norm_annex(anex):
                return r
        for r in rows:
            if str(r.get("CICLE", "")).strip() == str(cicle_selected).strip():
                return r
        return rows[0]

    # --- TOOLBAR ---
    def _build_toolbar(self, parent):
        ttk.Label(parent, text="Ciclo:").pack(side="left")
        cycles = sorted(self.df["CICLE"].astype(str).unique(), key=lambda x: (len(x), x))
        self.cb_cycle = ttk.Combobox(parent, values=cycles, state="readonly", width=12, justify="center")
        if cycles: self.cb_cycle.current(0)
        self.cb_cycle.pack(side="left", padx=6)
        self.cb_cycle.bind("<<ComboboxSelected>>", lambda e: self._reload_and_commit())

        btn_save = ttk.Button(parent, text="Save (Ctrl+S)", command=self.save_to_excel)
        btn_save.pack(side="left", padx=4)

        ttk.Label(parent, text="Filter by status").pack(side="left", padx=(24,4))
        self.filter_states = ["(All)", "Received & Scanned", "Received", "Scanned", "Pending Receipt", "Pending > 1 Month"]
        self.filter_state = ttk.Combobox(parent, values=self.filter_states, state="readonly", width=22, justify="center")
        self.filter_state.current(0)
        self.filter_state.pack(side="left", padx=(0,4))
        self.filter_state.bind("<<ComboboxSelected>>", lambda e: self._reload_and_commit())

        ttk.Button(parent, text="Set Received", command=lambda: self._bulk_apply("R")).pack(side="left", padx=2)
        ttk.Button(parent, text="Set Scanned", command=lambda: self._bulk_apply("S")).pack(side="left", padx=2)
        ttk.Button(parent, text="Set Pending", command=lambda: self._bulk_apply("PR")).pack(side="left", padx=2)
        ttk.Button(parent, text="Clear Checks", command=self._bulk_clear).pack(side="left", padx=6)

    # --- LEYENDA ---
    def _build_legend(self, parent):
        for s in ["Received & Scanned", "Received", "Scanned", "Pending Receipt", "Pending > 1 Month"]:
            tk.Label(parent, text="  ", bg=COLORS[s], relief="groove", width=3).pack(side="left", padx=5, pady=2)
            ttk.Label(parent, text=s).pack(side="left", padx=(0,12))

    # --- MATRIZ (tksheet) ---
    def _build_matrix_sheet(self, parent):
        self.matrix_sheet = Sheet(
            parent,
            data=[[""]],
            headers=[],
            show_top_left=False,
            width=820,
            height=600
        )
        # Selección estilo Windows (Ctrl/Shift/drag)
        self.matrix_sheet.enable_bindings((
            "single_select", "toggle_select", "shift_select", "ctrl_select",
            "drag_select_cells", "select_all",
            "arrowkeys", "edit_cell", "copy", "cut", "paste",
            "right_click_popup_menu", "rc_select",
        ))
        self.matrix_sheet.grid(row=0, column=0, sticky="nsew")
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        # Título del índice lateral
        try:
            self.matrix_sheet.set_index_title("Anexo/ID")
        except Exception:
            try:
                self.matrix_sheet.set_index_name("Anexo/ID")
            except Exception:
                pass

        # Evento virtual (y fallbacks) para cargar el editor
        self.matrix_sheet.bind("<<SheetSelect>>", self._on_matrix_any_select, add="+")
        self.matrix_sheet.extra_bindings([
            ("cell_select", self._on_matrix_any_select),
            ("rc_select", self._on_matrix_any_select),
            ("drag_select_cells", self._on_matrix_any_select),
            ("row_select", self._on_matrix_any_select),
            ("column_select", self._on_matrix_any_select),
            ("cell_edit", lambda e: "break"),
        ])

        # Autosize de columnas (evitar scroll horizontal)
        self.matrix_sheet.bind("<Configure>", lambda e: self._autosize_matrix_columns())

        try:
            self.matrix_sheet.set_index_width(96)
        except Exception:
            pass

    # --- EDITOR (derecha, con checkboxes) ---
    def _build_editor(self, parent):
        parent.grid_columnconfigure(0, weight=1)

        self.editor_info = ttk.Label(parent, text="ANNEX:", font=("Segoe UI", 10, "bold"))
        self.editor_info.grid(row=0, column=0, sticky="w")
        self.editor_desc = ttk.Label(parent, text="", font=("Segoe UI", 9), wraplength=440, justify="left")
        self.editor_desc.grid(row=1, column=0, sticky="w", pady=(2, 8))

        self.info_panel = ttk.Frame(parent)
        self.info_panel.grid(row=2, column=0, sticky="ew", pady=(0,8))
        self.info_panel.grid_columnconfigure(1, weight=1)

        self.info_labels = [
            ("API", None),
            ("PRODUCT", None),
            ("CODES", None),
            ("ANNEX DEADLINE (8 WEEKS / 56 DAYS)", None),
            ("REPORT ISSUANCE (90 DAYS)", None),
            ("DEADLINE FOR SIGNING (120 DAYS)", None),
        ]
        for i, (k, _) in enumerate(self.info_labels):
            ttk.Label(self.info_panel, text=k + ":", width=34, anchor="e").grid(row=i, column=0, sticky="e", padx=(0,6), pady=1)
            val = ttk.Label(self.info_panel, text="", wraplength=400, justify="left", anchor="w")
            val.grid(row=i, column=1, sticky="w", pady=1)
            self.info_labels[i] = (k, val)

        # === Totales ARRIBA ===
        self.global_frame = ttk.Frame(parent)
        self.global_frame.grid(row=3, column=0, sticky="ew", pady=(6, 8))
        for col in range(3):
            self.global_frame.grid_columnconfigure(col, weight=1)

        self.global_hdr_var = tk.StringVar(value="All files in current view: 0")
        ttk.Label(self.global_frame, textvariable=self.global_hdr_var,
                  font=("Segoe UI", 9, "bold"), anchor="center").grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 6))

        header_font = ("Segoe UI", 9, "bold")
        ttk.Label(self.global_frame, text=" ", anchor="center").grid(row=1, column=0, sticky="ew")
        ttk.Label(self.global_frame, text="Total files", font=header_font, anchor="center").grid(row=1, column=1, sticky="ew")
        ttk.Label(self.global_frame, text="% Total files", font=header_font, anchor="center").grid(row=1, column=2, sticky="ew")

        self.global_tbl_vars = {}
        for i, rname in enumerate(["Received", "Scanned", "Pending Receipt"], start=2):
            ttk.Label(self.global_frame, text=rname, anchor="center").grid(row=i, column=0, sticky="ew", padx=(0, 6))
            v_total = tk.StringVar(value="0")
            v_pct   = tk.StringVar(value="0.0%")
            ttk.Label(self.global_frame, textvariable=v_total, anchor="center", relief="groove").grid(row=i, column=1, sticky="ew", padx=(0, 6))
            ttk.Label(self.global_frame, textvariable=v_pct,   anchor="center", relief="groove").grid(row=i, column=2, sticky="ew")
            self.global_tbl_vars[rname] = (v_total, v_pct)

        # Mini encabezados de lista (PL / R / S / PR)
        hdr = ttk.Frame(parent)
        hdr.grid(row=4, column=0, sticky="ew", pady=(2,2))
        head_font = ("Segoe UI", 8, "bold")
        ttk.Label(hdr, text="PL", font=head_font, width=18, anchor="center").grid(row=0, column=0, padx=2, sticky="nsew")
        ttk.Label(hdr, text="R",  font=head_font, width=4,  anchor="center").grid(row=0, column=1, padx=2, sticky="nsew")
        ttk.Label(hdr, text="S",  font=head_font, width=4,  anchor="center").grid(row=0, column=2, padx=2, sticky="nsew")
        ttk.Label(hdr, text="PR", font=head_font, width=4,  anchor="center").grid(row=0, column=3, padx=2, sticky="nsew")

        # Contenedor scrollable para las plantas con checkboxes
        body = ttk.Frame(parent)
        body.grid(row=5, column=0, sticky="nsew")
        parent.grid_rowconfigure(5, weight=1)
        self.sub_canvas = tk.Canvas(body, height=480, borderwidth=0, highlightthickness=0)
        self.sub_frame = ttk.Frame(self.sub_canvas)
        self.sub_scroll = ttk.Scrollbar(body, orient="vertical", command=self.sub_canvas.yview)
        self.sub_canvas.configure(yscrollcommand=self.sub_scroll.set)

        self.sub_canvas.grid(row=0, column=0, sticky="nsew")
        self.sub_scroll.grid(row=0, column=1, sticky="ns")
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        self.sub_window = self.sub_canvas.create_window((0,0), window=self.sub_frame, anchor="nw")
        self.sub_frame.bind("<Configure>", lambda e: self.sub_canvas.configure(scrollregion=self.sub_canvas.bbox("all")))
        self.sub_canvas.bind("<Configure>", lambda e: self.sub_canvas.itemconfig(self.sub_window, width=e.width))

    # ---------- RENDER / RELOAD ----------
    def _reload_and_commit(self):
        self.render_matrix()

    def _header_text_for_id(self, pid: str) -> str:
        """
        Encabezado de columna:
        API
        RAP: dd-Mmm-YYYY – dd-Mmm-YYYY
        """
        selected_cicle = self.cb_cycle.get()
        rid = _norm_id(pid)
        rows = self.info_rows_by_id.get(rid, []) or self.info_rows_by_id.get(str(pid).strip(), [])
        chosen = None
        if rows:
            for r in rows:
                if str(r.get("CICLE", "")).strip() == str(selected_cicle).strip():
                    chosen = r; break
            if not chosen:
                chosen = rows[0]

        api = _get_val(chosen or {}, "API")
        d_s = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD START"))
        d_e = parse_date_ddmmyyyy(_get_val(chosen or {}, "RAP PERIOD END"))
        s_fmt = _fmt_date_dd_mmm(d_s) or "-"
        e_fmt = _fmt_date_dd_mmm(d_e) or "-"
        return f"{api or ''}\nRAP: {s_fmt} – {e_fmt}".strip()

    def _cell_summary_lines(self, grp: pd.DataFrame, key: tuple) -> (str, str, List[str]):
        states = grp["__state__"].tolist()
        group_state = summarize_group_status(states)
        bg = COLORS.get(group_state, "#ffffff")

        lines = [group_state if group_state else ""]
        resp = self.annex_resp.get(_norm_annex(key[1]), "")
        if resp:
            lines.append(f"Responsible Area: {resp}")
        for _, r in grp.iterrows():
            plant = (r.get("PLANT","") or "").strip()
            st = r["__state__"]
            if st == "Pending > 1 Month": mini = "!!"
            elif st == "Pending Receipt": mini = "!"
            elif st == "Received & Scanned": mini = "✓✓"
            elif st == "Received": mini = "✓"
            elif st == "Scanned": mini = "S"
            else: mini = "-"
            lines.append(f"{plant}: {mini}")
        return group_state, bg, lines

    def render_matrix(self):
        self.cells_map.clear()
        self.current_group_key = None

        df = self.df.copy()
        selected = self.cb_cycle.get()
        if selected:
            df = df[df["CICLE"].astype(str) == selected]
        df["__state__"] = df.apply(derive_status_per_row, axis=1)

        state_filter = getattr(self, "filter_state", None)
        if state_filter:
            sel_state = state_filter.get()
            if sel_state and sel_state != "(All)":
                df = df[df["__state__"] == sel_state]

        self.ids = list(dict.fromkeys([_norm_id(x) for x in df["ID"].astype(str).tolist()]))
        try:
            self.anexos = sorted({int(_norm_annex(x)) for x in df["ANNEX"].astype(str).tolist() if str(x).strip().isdigit()})
            self.anexos = [str(a) for a in self.anexos]
        except Exception:
            self.anexos = list(dict.fromkeys([_norm_annex(x) for x in df["ANNEX"].astype(str).tolist()]))
        if not self.anexos:
            self.anexos = [str(i) for i in range(1,19)]
        self.anexos = list(dict.fromkeys([_norm_annex(a) for a in self.anexos]))

        self.group_exists = {}
        for pid in self.ids:
            for an in self.anexos:
                exists = len(df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                                (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(an))]) > 0
                self.group_exists[(str(pid), str(an))] = exists

        headers = [self._header_text_for_id(pid) for pid in self.ids]

        data = []
        bg_map = {}
        for i, an in enumerate(self.anexos):
            row_cells = []
            for j, pid in enumerate(self.ids):
                grp = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                         (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(an))]
                key = (str(pid), str(an))
                if len(grp)==0:
                    row_cells.append("")
                    continue
                _, bg, lines = self._cell_summary_lines(grp, key)
                row_cells.append("\n".join([ln for ln in lines if ln]))
                bg_map[(i, j)] = bg
            data.append(row_cells)

        self.matrix_sheet.set_sheet_data(data, reset_col_positions=True, reset_row_positions=True)
        self.matrix_sheet.headers(headers)
        self.matrix_sheet.row_index(newindex=[str(a) for a in self.anexos])
        try:
            self.matrix_sheet.set_index_title("Anexo/ID")
        except Exception:
            try:
                self.matrix_sheet.set_index_name("Anexo/ID")
            except Exception:
                pass

        for (r, c), color in bg_map.items():
            self.matrix_sheet.highlight_cells(row=r, column=c, bg=color)

        for i, an in enumerate(self.anexos):
            for j, pid in enumerate(self.ids):
                if self.group_exists.get((pid, an)):
                    self.cells_map[(i, j)] = {"key": (pid, an)}

        # Ajustar columnas para evitar scroll horizontal
        self.after(0, self._autosize_matrix_columns)

        # Selección inicial para cargar el panel derecho al abrir
        try:
            first = next(((r, c) for r in range(len(self.anexos)) for c in range(len(self.ids)) if (r, c) in self.cells_map), None)
            if first:
                self.matrix_sheet.select_cell(first[0], first[1], redraw=True)
                self._on_matrix_any_select()
        except Exception:
            pass

        self._update_global_table_inline()

    # ---------- Selección robusta ----------
    def _on_matrix_any_select(self, event=None):
        cs = self.matrix_sheet.get_currently_selected()
        if not cs or cs[0] != "cell":
            return
        r, c = cs[1], cs[2]
        info = self.cells_map.get((r, c))
        if not info:
            return
        key = info["key"]
        if key != self.current_group_key:
            self.current_group_key = key
            self._load_group_in_editor(key)

    # ---------- Autosize columnas ----------
    def _autosize_matrix_columns(self):
        """Reparte el ancho disponible entre columnas para evitar scroll horizontal."""
        try:
            total = self.matrix_sheet.winfo_width()
            if total <= 1:
                self.after(50, self._autosize_matrix_columns)
                return
            index_w = 96
            margins = 20
            ncols = max(1, len(self.ids))
            avail = max(200, total - index_w - margins)
            col_w = int(avail / ncols)
            col_w = max(160, min(col_w, 320))
            for j in range(ncols):
                self.matrix_sheet.column_width(column=j, width=col_w, only_set_if_too_small=False)
        except Exception:
            pass

    # ---------- EDITOR ----------
    def _clear_editor(self):
        for w in self.sub_frame.winfo_children():
            w.destroy()
        self.editor_info.configure(text="ANNEX=")
        self.editor_desc.configure(text="")
        self.editor_rows = []
        if hasattr(self, "info_labels"):
            for _, lbl in self.info_labels:
                lbl.configure(text="")

    def _update_global_table_inline(self):
        if not hasattr(self, "global_tbl_vars"):
            return

        df = self.df.copy()
        selected = self.cb_cycle.get()
        if selected:
            df = df[df["CICLE"].astype(str) == selected]
        df["__state__"] = df.apply(derive_status_per_row, axis=1)

        sel_state = self.filter_state.get() if getattr(self, "filter_state", None) else "(All)"
        if sel_state and sel_state != "(All)":
            df = df[df["__state__"] == sel_state]

        existing_groups = 0
        for pid in self.ids:
            for anex in self.anexos:
                if len(df[(df["ID"].astype(str).map(_norm_id)==_norm_id(pid)) &
                          (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))]) > 0:
                    existing_groups += 1

        total_files = existing_groups
        self.global_hdr_var.set(f"All files in current view: {total_files}")

        received_groups = scanned_groups = pending_groups = 0
        for pid in self.ids:
            for anex in self.anexos:
                grp = df[(df["ID"].astype(str).map(_norm_id) == _norm_id(pid)) &
                         (df["ANNEX"].astype(str).map(_norm_annex) == _norm_annex(anex))]
                if grp.empty: continue
                group_state = summarize_group_status(grp["__state__"].tolist())
                if group_state in ("Received", "Received & Scanned"): received_groups += 1
                if group_state in ("Scanned", "Received & Scanned"):  scanned_groups += 1
                if group_state.startswith("Pending"):                  pending_groups += 1

        def pct(n):
            return f"{(n/total_files*100):.1f}%" if total_files > 0 else "0.0%"

        self.global_tbl_vars["Received"][0].set(str(received_groups))
        self.global_tbl_vars["Received"][1].set(pct(received_groups))
        self.global_tbl_vars["Scanned"][0].set(str(scanned_groups))
        self.global_tbl_vars["Scanned"][1].set(pct(scanned_groups))
        self.global_tbl_vars["Pending Receipt"][0].set(str(pending_groups))
        self.global_tbl_vars["Pending Receipt"][1].set(pct(pending_groups))

    def _load_group_in_editor(self, key: tuple):
        self._clear_editor()
        id_, anex = key

        self.editor_info.configure(text=f"ANNEX={anex}")
        self.editor_desc.configure(text=self.annex_desc.get(_norm_annex(anex), ""))

        selected_cicle = self.cb_cycle.get()
        info = self._pick_info_row(str(id_), str(anex), str(selected_cicle)) or {}

        codes_val = _get_val(info, "CODES", "CODE")

        def _fmt_cell(v: str, is_date: bool = False) -> str:
            if not is_date: return v or ""
            d = parse_date_ddmmyyyy(v)
            return _fmt_date_dd_mmm(d) if d else (v or "")

        date_keys = {
            "ANNEX DEADLINE (8 WEEKS / 56 DAYS)",
            "REPORT ISSUANCE (90 DAYS)",
            "DEADLINE FOR SIGNING (120 DAYS)",
        }

        for k, lbl in self.info_labels:
            if k == "CODES":
                lbl.configure(text=codes_val)
            else:
                val = info.get(k, "")
                lbl.configure(text=_fmt_cell(val, k in date_keys))

        idxs = self.df[(self.df["ID"].astype(str).map(_norm_id)==_norm_id(id_)) &
                       (self.df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))].index.tolist()

        self.editor_rows = []
        rownum = 0
        for df_index in idxs:
            row = self.df.loc[df_index]
            plant = row.get("PLANT","")

            ttk.Label(self.sub_frame, text=plant, width=18, wraplength=160,
                      justify="center", anchor="center").grid(row=rownum, column=0, padx=2, pady=2, sticky="n")

            def is_on(v):
                return str(v).strip().lower() in {"1","true","x","✓","si","sí"}

            v_r = tk.IntVar(value=1 if is_on(row.get("Received","")) else 0)
            v_s = tk.IntVar(value=1 if is_on(row.get("Scanned","")) else 0)
            v_p = tk.IntVar(value=1 if is_on(row.get("Pending Receipt","")) else 0)

            def refresh_state(vr=v_r, vs=v_s, vp=v_p, dfi=df_index):
                r = "1" if vr.get()==1 else ""
                s = "1" if vs.get()==1 else ""
                p = "1" if vp.get()==1 else ""
                if r == "1" and p == "1":
                    p = ""; vp.set(0)
                self.df.at[dfi, "Received"] = r
                self.df.at[dfi, "Scanned"]  = s
                self.df.at[dfi, "Pending Receipt"] = p
                deriv = compute_persisted_fields(r, s, p, self.df.at[dfi, "RAP PERIOD END"])
                self.df.at[dfi, "Received & Scanned"] = deriv["Received & Scanned"]
                self.df.at[dfi, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                self._dirty_indices.add(dfi)
                self._refresh_selected_cell_summary()

            def on_toggle_r(vr=v_r, vp=v_p, *args):
                if vr.get() == 1 and vp.get() == 1:
                    vp.set(0)
                refresh_state()

            def on_toggle_pr(vr=v_r, vp=v_p, *args):
                if vp.get() == 1 and vr.get() == 1:
                    vr.set(0)
                refresh_state()

            def on_toggle_s(*args):
                refresh_state()

            ttk.Checkbutton(self.sub_frame, variable=v_r, command=on_toggle_r).grid(row=rownum, column=1, padx=(8,0), sticky="n")
            ttk.Checkbutton(self.sub_frame, variable=v_s, command=on_toggle_s).grid(row=rownum, column=2, padx=(8,0), sticky="n")
            ttk.Checkbutton(self.sub_frame, variable=v_p, command=on_toggle_pr).grid(row=rownum, column=3, padx=(8,0), sticky="n")

            ttk.Label(self.sub_frame, text="R").grid(row=rownum, column=1, sticky="e", padx=(28,0))
            ttk.Label(self.sub_frame, text="S").grid(row=rownum, column=2, sticky="e", padx=(28,0))
            ttk.Label(self.sub_frame, text="PR").grid(row=rownum, column=3, sticky="e", padx=(28,0))

            self.editor_rows.append({"df_index": df_index, "v_r": v_r, "v_s": v_s, "v_p": v_p})
            rownum += 1

        self._update_global_table_inline()

    def _refresh_selected_cell_summary(self):
        if not self.current_group_key:
            return
        id_, anex = self.current_group_key
        try:
            r = self.anexos.index(str(anex))
            c = self.ids.index(str(id_))
        except ValueError:
            return

        df = self.df.copy()
        sel = self.cb_cycle.get()
        if sel:
            df = df[df["CICLE"].astype(str) == sel]
        df["__state__"] = df.apply(derive_status_per_row, axis=1)

        grp = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(id_)) &
                 (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))]
        if grp.empty:
            self.matrix_sheet.set_cell_data(r, c, "")
            self.matrix_sheet.highlight_cells(row=r, column=c, bg="#ffffff")
        else:
            _, bg, lines = self._cell_summary_lines(grp, (id_, anex))
            txt = "\n".join([ln for ln in lines if ln])
            self.matrix_sheet.set_cell_data(r, c, txt)
            self.matrix_sheet.highlight_cells(row=r, column=c, bg=bg)

        self._update_global_table_inline()

    def _commit_editor_changes_to_df(self):
        return

    # ---------- ACCIONES MASIVAS ----------
    def _apply_state_to_group(self, key: tuple, mode: str):
        df = self.df
        idxs = df[(df["ID"].astype(str).map(_norm_id)==_norm_id(key[0])) &
                  (df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(key[1]))].index.tolist()
        for idx in idxs:
            if mode == "R":
                r, s, p = "1", df.at[idx, "Scanned"], ""
            elif mode == "S":
                r, s, p = df.at[idx, "Received"], "1", df.at[idx, "Pending Receipt"]
            else:  # "PR"
                r, s, p = "", df.at[idx, "Scanned"], "1"
            if r == "1" and p == "1": p = ""
            if p == "1" and r == "1": r = ""
            df.at[idx, "Received"] = r
            df.at[idx, "Scanned"]  = s
            df.at[idx, "Pending Receipt"] = p
            deriv = compute_persisted_fields(r, s, p, df.at[idx, "RAP PERIOD END"])
            df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
            df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
            self._dirty_indices.add(idx)

    def _bulk_apply(self, mode: str):
        sels = self.matrix_sheet.get_selected_cells()
        targets = set()
        for (r, c) in sels:
            info = self.cells_map.get((r, c))
            if info: targets.add(info["key"])
        if not targets and self.current_group_key:
            targets = {self.current_group_key}
        if not targets: return

        for k in targets:
            self._apply_state_to_group(k, mode)
        for k in targets:
            self.current_group_key = k
            self._refresh_selected_cell_summary()
        if self.current_group_key:
            self._load_group_in_editor(self.current_group_key)

    def _bulk_clear(self):
        sels = self.matrix_sheet.get_selected_cells()
        targets = set()
        for (r, c) in sels:
            info = self.cells_map.get((r, c))
            if info: targets.add(info["key"])
        if not targets and self.current_group_key:
            targets = {self.current_group_key}
        if not targets: return

        for k in targets:
            id_, anex = k
            idxs = self.df[(self.df["ID"].astype(str).map(_norm_id)==_norm_id(id_)) &
                           (self.df["ANNEX"].astype(str).map(_norm_annex)==_norm_annex(anex))].index.tolist()
            for idx in idxs:
                self.df.at[idx, "Received"] = ""
                self.df.at[idx, "Scanned"]  = ""
                self.df.at[idx, "Pending Receipt"] = ""
                deriv = compute_persisted_fields("", "", "", self.df.at[idx, "RAP PERIOD END"])
                self.df.at[idx, "Received & Scanned"] = deriv["Received & Scanned"]
                self.df.at[idx, "Pending > 1 Month"]  = deriv["Pending > 1 Month"]
                self._dirty_indices.add(idx)

        for k in targets:
            self.current_group_key = k
            self._refresh_selected_cell_summary()
        if self.current_group_key:
            self._load_group_in_editor(self.current_group_key)

    # ---------- GUARDAR ----------
    def _toast(self, text: str, ms: int = 2500, fg: str = None):
        toast = tk.Toplevel(self)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)
        frm = ttk.Frame(toast, padding=(10,6))
        frm.pack(fill="both", expand=True)
        lbl = ttk.Label(frm, text=text)
        if fg:
            try: lbl.configure(foreground=fg)
            except Exception: pass
        lbl.pack()
        self.update_idletasks()
        x = self.winfo_x() + self.winfo_width() - 420
        y = self.winfo_y() + 20
        toast.geometry(f"400x40+{x}+{y}")
        toast.after(ms, toast.destroy)

    def save_to_excel(self):
        self._toast(f"Guardando: {self.xlsx_path}", ms=2500, fg="#1f4e79")
        now = datetime.now().strftime(NOW_FMT)
        if "Updated on" not in self.df.columns:
            self.df["Updated on"] = ""
        for idx in sorted(self._dirty_indices):
            if idx in self.df.index:
                self.df.at[idx, "Updated on"] = now

        try:
            df_to_write = self.df.copy()
            for col in ["Received","Scanned","Pending Receipt","Received & Scanned","Pending > 1 Month"]:
                if col in df_to_write.columns:
                    df_to_write[col] = (
                        df_to_write[col].astype(str)
                                        .str.strip()
                                        .replace({"0": "", "nan": ""})
                                        .fillna("")
                    )
            write_excel_table(df_to_write, self.xlsx_path, self.sheet, self.table)
            self._dirty_indices.clear()
        except PermissionError:
            messagebox.showerror("Archivo en uso", "Cierra el Excel y vuelve a intentar.")
        except Exception as e:
            messagebox.showerror("Error al guardar", str(e))


# ---------- MAIN ----------
if __name__ == "__main__":
    if not os.path.exists(XLSX_PATH):
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("No encontrado", f"No existe:\n{XLSX_PATH}")
        root.destroy()
    else:
        app = MatrixApp(XLSX_PATH, SHEET_NAME, TABLE_NAME)
        app.mainloop()
