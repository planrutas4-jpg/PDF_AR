import os
import re
from pypdf import PdfReader, PdfWriter

def unir_pdfs(carpeta):
    writer = PdfWriter()

    # Listar todos los PDFs que contengan al menos un número en su nombre
    pdfs = [f for f in os.listdir(carpeta) if f.lower().endswith(".pdf") and re.search(r'\d', f)]
    if not pdfs:
        print("No se encontraron archivos PDF con número en el nombre.")
        return None

    # Función para extraer el último número del nombre del archivo
    def extraer_numero(nombre):
        match = re.findall(r'(\d+)', nombre)
        return int(match[-1])

    # Ordenar los PDFs según el último número
    pdfs.sort(key=extraer_numero)

    print("Archivos en orden de unión:")
    for pdf in pdfs:
        print(pdf)

    # Leer cada PDF y agregar todas sus páginas
    for pdf in pdfs:
        ruta_pdf = os.path.join(carpeta, pdf)
        try:
            reader = PdfReader(ruta_pdf)
            for page in reader.pages:
                writer.add_page(page)
        except Exception as e:
            print(f"Error leyendo {pdf}: {e}")

    # Guardar PDF final
    ruta_salida = os.path.join(carpeta, "PDF_All.pdf")
    with open(ruta_salida, "wb") as f:
        writer.write(f)

    print(f"Todos los PDFs con número se han unido en: {ruta_salida}")
    return ruta_salida

