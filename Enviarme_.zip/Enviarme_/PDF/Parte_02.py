import os
import io
import sys
import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk

IS_MAC = sys.platform == "darwin"
IS_WIN = sys.platform.startswith("win")

class PDFRotatorGridApp:
    MINI_W_MAX = 140
    MINI_H_MAX = 190
    COLUMNAS_INICIAL = 8
    MARGEN = 6
    PREVIEW_CHUNK = 6

    COLOR_SELECCIONADO = "blue"
    COLOR_NO_SELECCIONADO = "gray"

    def __init__(self, root):
        self.root = root
        self.root.title("SpinPDF_AR_vr.0010_auto")
        self.root.geometry("1300x650+10+10")

        ico = os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico")
        if IS_WIN and os.path.exists(ico):
            try:
                self.root.iconbitmap(ico)
            except Exception:
                pass

        # Estado
        self.doc = None
        self.ruta_pdf = None
        self.num_paginas = 0
        self.rotaciones = []
        self.tk_thumbs = []
        self.cards = []
        self.labels_imagen = []
        self.labels_num = []
        self.seleccionadas = []
        self.last_clicked_index = None
        self.columnas_actuales = self.COLUMNAS_INICIAL
        self._notice_after_id = None

        # ===== Barra superior =====
        top = tk.Frame(root); top.pack(fill="x", pady=5)

        # Barra de notificaciones (oculta por defecto)
        self.notice = tk.Label(
            top, text="", anchor="w", fg="#084ebd", bg="#e6f0ff",
            font=("Arial", 10), padx=10, pady=4, relief="groove", bd=1
        )
        self.notice.pack(fill="x")
        self.notice.pack_forget()

        left = tk.Frame(top); left.pack(side="left", padx=5)
        tk.Button(left, text="Abrir PDF", command=self.seleccionar_pdf).pack(side="left", padx=2)

        # Botones de ROTACIÓN GLOBAL (aplican a la selección)
        rot = tk.Frame(top); rot.pack(side="left", padx=12)
        tk.Label(rot, text="Rotar selección:").pack(side="left", padx=(0,6))
        tk.Button(rot, text="↶ 90°", command=lambda: self.rotar_seleccionadas(-90)).pack(side="left", padx=2)
        tk.Button(rot, text="↷ 90°", command=lambda: self.rotar_seleccionadas( 90)).pack(side="left", padx=2)
        tk.Button(rot, text="180°",  command=lambda: self.rotar_seleccionadas(180)).pack(side="left", padx=2)

        # Autodetección (solo rápida)
        auto = tk.Frame(top); auto.pack(side="left", padx=12)
        tk.Label(auto, text="Autodetectar:").pack(side="left", padx=(0,6))
        tk.Button(auto, text="Auto (rápido)", command=self.auto_rotate_fast_selected).pack(side="left", padx=2)

        self.btn_guardar = tk.Button(top, text="Guardar como...", command=self.guardar_pdf_como, state="disabled")
        self.btn_guardar.pack(side="right", padx=5)

        self.lbl_ruta = tk.Label(top, text="Archivo: Ninguno", font=("Arial",9))
        self.lbl_ruta.pack(side="bottom", fill="x", pady=2)

        # ===== Selección rápida =====
        sel = tk.Frame(root); sel.pack(fill="x", pady=2)
        for txt, cmd in [("Seleccionar todo", self.seleccionar_todo),
                         ("Deseleccionar todo", self.deseleccionar_todo),
                         ("Pares", self.seleccionar_pares),
                         ("Impares", self.seleccionar_impares),
                         ("Invertir", self.invertir_seleccion)]:
            tk.Button(sel, text=txt, command=cmd).pack(side="left", padx=2)

        # ===== Canvas con scroll + responsive =====
        cont = tk.Frame(root); cont.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(cont)
        self.scroll_y = tk.Scrollbar(cont, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scroll_y.set)
        self.inner = tk.Frame(self.canvas)
        self.canvas_window = self.canvas.create_window((0,0), window=self.inner, anchor="nw")
        self.canvas.pack(fill="both", expand=True, side="left")
        self.scroll_y.pack(fill="y", side="right")

        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self._bind_scroll(self.canvas)

    # -------- Notificaciones superiores --------
    def _notify(self, text, kind="info", duration_ms=5000):
        if kind == "info":
            fg, bg = "#084ebd", "#e6f0ff"
        elif kind == "error":
            fg, bg = "#8b0000", "#ffe6e6"
        else:
            fg, bg = "#333", "#eee"
        self.notice.config(text=text, fg=fg, bg=bg)
        try:
            self.notice.pack_info()
        except Exception:
            self.notice.pack(fill="x")
        if self._notice_after_id:
            self.root.after_cancel(self._notice_after_id)
        self._notice_after_id = self.root.after(duration_ms, self._hide_notice)

    def _hide_notice(self):
        try:
            self.notice.pack_forget()
        except Exception:
            pass
        self._notice_after_id = None

    # -------- Utilidades UI / progreso / scroll --------
    def _bind_scroll(self, widget):
        widget.bind_all("<MouseWheel>", self._on_mousewheel)
        widget.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        widget.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll( 1, "units"))

    def _on_mousewheel(self, event):
        if IS_MAC:
            self.canvas.yview_scroll(int(-1*event.delta), "units")
        else:
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def _barra_progreso(self, titulo, max_val):
        win = tk.Toplevel(self.root); win.title(titulo); win.geometry("420x90"); win.resizable(False, False)
        try:
            ico = os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico")
            if IS_WIN and os.path.exists(ico): win.iconbitmap(ico)
        except Exception:
            pass
        tk.Label(win, text=titulo).pack(pady=5)
        bar = ttk.Progressbar(win, orient="horizontal", length=360, mode="determinate", maximum=max_val)
        bar.pack(pady=5); win.update()
        return win, bar

    # -------- Flujo principal --------
    def seleccionar_pdf(self):
        ruta = filedialog.askopenfilename(title="Seleccionar PDF", filetypes=[("PDF Files","*.pdf")])
        if ruta:
            self.cargar_pdf(ruta)

    def cargar_pdf(self, ruta):
        try:
            if self.doc: self.doc.close()
            self.doc = fitz.open(ruta)
            self.ruta_pdf = ruta
            self.lbl_ruta.config(text=f"Archivo: {ruta}")
            self.num_paginas = self.doc.page_count

            # Preasignación por índice
            self.rotaciones    = [0]*self.num_paginas
            self.tk_thumbs     = [None]*self.num_paginas
            self.cards         = [None]*self.num_paginas
            self.labels_imagen = [None]*self.num_paginas
            self.labels_num    = [None]*self.num_paginas
            self.seleccionadas = [False]*self.num_paginas
            self.last_clicked_index = None
            self.btn_guardar.config(state="normal")

            for w in self.inner.winfo_children(): w.destroy()

            self._cargar_previews_async()
        except Exception as e:
            self._notify(f"Error al abrir PDF: {e}", kind="error")

    def _cargar_previews_async(self):
        self.prog_win, self.prog_bar = self._barra_progreso("Cargando PDF...", self.num_paginas)
        self._preview_index = 0
        self._preview_chunk()

    def _preview_chunk(self):
        s = self._preview_index
        e = min(self._preview_index + self.PREVIEW_CHUNK, self.num_paginas)
        for i in range(s, e):
            try:
                self._render_preview_into_slot(i)
            except Exception as ex:
                print(f"Preview pág {i+1} falló: {ex}", file=sys.stderr)
                from PIL import Image as PILImage
                dummy = PILImage.new("RGB", (self.MINI_W_MAX, self.MINI_H_MAX), "lightgray")
                img_tk = ImageTk.PhotoImage(dummy)
                self.tk_thumbs[i] = img_tk
                self._agregar_miniatura(i, img_tk)
            self.prog_bar["value"] = i+1; self.prog_bar.update()
        self._preview_index = e
        if self._preview_index < self.num_paginas:
            self.root.after(10, self._preview_chunk)
        else:
            self.prog_win.destroy()
            self._notify("PDF cargado correctamente", kind="info", duration_ms=2500)

    def _render_preview_into_slot(self, i):
        page = self.doc[i]
        rot  = int(self.rotaciones[i])
        pix  = page.get_pixmap(matrix=fitz.Matrix(2,2).prerotate(rot))
        img  = Image.open(io.BytesIO(pix.tobytes("png")))
        img.thumbnail((self.MINI_W_MAX, self.MINI_H_MAX), Image.LANCZOS)
        img_tk = ImageTk.PhotoImage(img)
        self.tk_thumbs[i] = img_tk
        self._agregar_miniatura(i, img_tk)

    # -------- Responsive --------
    def _on_canvas_resize(self, event):
        card_w = self.MINI_W_MAX + self.MARGEN*2 + 4
        if card_w <= 0: return
        cols = max(1, min(16, event.width // card_w))
        if cols != self.columnas_actuales:
            self.columnas_actuales = cols
            self._reflow_grid()

    def _reflow_grid(self):
        for i, cont in enumerate(self.cards):
            if not cont: continue
            r = i // self.columnas_actuales
            c = i % self.columnas_actuales
            cont.grid_configure(row=r, column=c, padx=self.MARGEN, pady=self.MARGEN)

    # -------- Miniatura / tarjeta --------
    def _agregar_miniatura(self, i, img_tk):
        cont = tk.Frame(self.inner)
        self.cards[i] = cont
        r = i // self.columnas_actuales
        c = i % self.columnas_actuales
        cont.grid(row=r, column=c, padx=self.MARGEN, pady=self.MARGEN)

        img_lbl = tk.Label(cont, image=img_tk, borderwidth=2, relief="solid", highlightthickness=2)
        img_lbl.pack()
        img_lbl.bind("<Button-1>", lambda e, idx=i: self.seleccionar_pagina(idx, e))
        self.labels_imagen[i] = img_lbl

        txt = tk.Label(cont, text=f"Pág. {i+1} (rot: {self.rotaciones[i]}°)")
        txt.pack(pady=2)
        self.labels_num[i] = txt

    # -------- Selección --------
    def seleccionar_pagina(self, i, e):
        # Multi-selección: Shift rango, Ctrl/Cmd toggle.
        shift = bool(e.state & 0x0001)     # Shift
        ctrl  = bool(e.state & 0x0004)     # Ctrl
        cmd   = IS_MAC and bool(e.state & 0x0008)
        mod   = ctrl or cmd

        if shift and self.last_clicked_index is not None:
            a, b = sorted([self.last_clicked_index, i])
            for j in range(a, b+1): self.seleccionadas[j] = True
        elif mod:
            self.seleccionadas[i] = not self.seleccionadas[i]
        else:
            self.seleccionadas = [False]*self.num_paginas
            self.seleccionadas[i] = True

        self.last_clicked_index = i
        self.actualizar_ui()

    def actualizar_ui(self):
        for i in range(self.num_paginas):
            lbl = self.labels_imagen[i]
            if not lbl: continue
            color = self.COLOR_SELECCIONADO if self.seleccionadas[i] else self.COLOR_NO_SELECCIONADO
            lbl.config(highlightbackground=color, highlightcolor=color)
            txt = self.labels_num[i]
            if txt:
                txt.config(text=f"Pág. {i+1} (rot: {self.rotaciones[i]}°)",
                           fg=("blue" if self.seleccionadas[i] else "black"))

    # ====== ROTACIÓN MANUAL ======
    def rotar_seleccionadas(self, grados):
        if not self.doc:
            self._notify("Abre un PDF primero", kind="error", duration_ms=3000)
            return
        if not any(self.seleccionadas):
            self._notify("Selecciona una o más páginas para rotar", kind="info", duration_ms=3000)
            return

        for i, sel in enumerate(self.seleccionadas):
            if not sel: continue
            self._apply_rotation(i, (self.rotaciones[i] + grados) % 360)

        self.actualizar_ui()

    # ====== AUTODETECCIÓN (rápida: sin OCR) ======
    def auto_rotate_fast_selected(self):
        """Heurística simple: si la página está apaisada (ancho>alto), rotar +90°."""
        if not self.doc:
            self._notify("Abre un PDF primero", "error", 3000); return
        if not any(self.seleccionadas):
            self._notify("Selecciona páginas para autodetectar", "info", 3000); return

        cambios = 0
        for i, sel in enumerate(self.seleccionadas):
            if not sel: continue
            page = self.doc[i]
            try:
                orig = page.rotation
            except Exception:
                orig = 0
            eff_rot = (orig + self.rotaciones[i]) % 360

            w, h = page.rect.width, page.rect.height
            target = 90 if w > h else 0

            delta = (target - eff_rot) % 360
            if delta != 0:
                self._apply_rotation(i, (self.rotaciones[i] + delta) % 360)
                cambios += 1

        self.actualizar_ui()
        if cambios:
            self._notify(f"Auto (rápido): se ajustaron {cambios} pág(s).", "info", 3500)
        else:
            self._notify("Auto (rápido): no se encontraron páginas para ajustar.", "info", 3500)

    # ====== Helpers de rotación / preview ======
    def _apply_rotation(self, i, new_rot):
        """Aplica rotación interna y re-renderiza miniatura."""
        self.rotaciones[i] = new_rot
        try:
            page = self.doc[i]
            pix = page.get_pixmap(matrix=fitz.Matrix(2,2).prerotate(int(new_rot)))
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            img.thumbnail((self.MINI_W_MAX, self.MINI_H_MAX), Image.LANCZOS)
            self.tk_thumbs[i] = ImageTk.PhotoImage(img)
            self.labels_imagen[i].config(image=self.tk_thumbs[i])
        except Exception as e:
            print(f"Re-preview pág {i+1} falló: {e}", file=sys.stderr)

    # -------- Guardado: aviso superior (sin messagebox) --------
    def guardar_pdf_como(self):
        if not self.doc:
            self._notify("No hay PDF abierto", kind="error", duration_ms=3500)
            return
        ruta = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files","*.pdf")])
        if not ruta:
            self._notify("Guardado cancelado", kind="info", duration_ms=2500)
            return

        win, bar = self._barra_progreso("Guardando PDF...", self.num_paginas)
        try:
            nuevo = fitz.open()
            nuevo.insert_pdf(self.doc, from_page=0, to_page=self.num_paginas-1)

            for i, ang in enumerate(self.rotaciones):
                page = nuevo[i]
                try:
                    orig = page.rotation  # /Rotate previo (0/90/180/270)
                except Exception:
                    orig = 0
                page.set_rotation(int((orig + ang) % 360))
                bar["value"] = i+1; bar.update()

            nuevo.save(ruta); nuevo.close()
            win.destroy()
            self._notify(f"PDF guardado en: {ruta}", kind="info", duration_ms=5000)
        except Exception as e:
            win.destroy()
            self._notify(f"Error al guardar: {e}", kind="error", duration_ms=7000)

    # -------- Selección rápida --------
    def seleccionar_todo(self):
        if self.num_paginas:
            self.seleccionadas = [True]*self.num_paginas
            self.actualizar_ui()
    def deseleccionar_todo(self):
        if self.num_paginas:
            self.seleccionadas = [False]*self.num_paginas
            self.actualizar_ui()
    def seleccionar_pares(self):
        if self.num_paginas:
            self.seleccionadas = [(i%2==1) for i in range(self.num_paginas)]
            self.actualizar_ui()
    def seleccionar_impares(self):
        if self.num_paginas:
            self.seleccionadas = [(i%2==0) for i in range(self.num_paginas)]
            self.actualizar_ui()
    def invertir_seleccion(self):
        if self.num_paginas:
            self.seleccionadas = [not v for v in self.seleccionadas]
            self.actualizar_ui()


# if __name__ == "__main__":
#     root = tk.Tk()
#     app = PDFRotatorGridApp(root)
#     root.mainloop()
