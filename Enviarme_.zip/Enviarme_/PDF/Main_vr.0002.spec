# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['Main_vr.0002.py'],
    pathex=[],
    binaries=[],
    datas=[('fondo.gif', '.'), ('Mi_icon_01.ico', '.'), ('Back.py', '.'), ('Parte_00.py', '.'), ('Parte_01.py', '.'), ('Parte_02.py', '.'), ('Parte_03.py', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Main_vr.0002',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['Mi_icon_01.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Main_vr.0002',
)
