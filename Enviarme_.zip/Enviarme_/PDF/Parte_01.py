import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import io
import os
import sys
import threading
import tempfile
from Parte_00 import unir_pdfs  # Función externa para unir PDFs


class PDFSelectorApp:
    MINIATURA_ANCHO = 140
    MINIATURA_ALTO = 190
    COLUMNAS = 8
    MARGEN = 5
    COLOR_SELECCIONADO = "blue"
    COLOR_NO_SELECCIONADO = "gray"

    def __init__(self, root):
        self.root = root
        self.root.title("NovaPDF_AR.vr.0003")
        self.root.geometry("1300x700+20+20")
        try:
            self.root.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))
        except Exception:
            pass

        # Variables PDF
        self.doc = None
        self.num_paginas = 0
        self.seleccionadas = []
        self.labels = []
        self.labels_num = []
        self.imagenes_tk = []

        # Ruta de guardado
        self.ruta_nuevo_pdf = ""

        # Selección
        self.last_clicked_index = None
        self.dragging = False
        self.indices_visitados = set()
        self.modo_separado = tk.BooleanVar(value=False)

        # Estado de teclado (cursor)
        self.cursor_index = 0

        # Config nombres
        self.nombre_base = tk.StringVar(value="MyPDF_")
        self.prefijo = tk.StringVar(value="")
        self.sufijo = tk.StringVar(value="")
        self.separador = tk.StringVar(value="_")
        self.digitos = tk.IntVar(value=3)
        self.start_num = tk.IntVar(value=1)

        self._crear_interface()
        self._bind_shortcuts()
        self._crear_preview_inicial()

    # ------------------------- UI -------------------------
    def _crear_interface(self):
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)

        # Banner de avisos (oculto)
        self.banner = tk.Label(self.main_frame, text="", bg="#e6f0ff", fg="#0b57d0",
                               font=("Arial", 10), anchor="w", padx=10)
        self.banner.pack(fill="x")
        self.banner.pack_forget()

        # Fila 1: botones + rango
        top_frame1 = tk.Frame(self.main_frame)
        top_frame1.pack(fill="x", pady=5, padx=6)

        tk.Button(top_frame1, text="Abrir PDF", command=self.seleccionar_archivo_pdf).pack(side="left", padx=5)

        menubutton = tk.Menubutton(top_frame1, text="Selección…", relief="raised")
        menu = tk.Menu(menubutton, tearoff=0)
        menu.add_command(label="Seleccionar/Deseleccionar (Todas)", command=self.toggle_todas_paginas)
        menu.add_separator()
        menu.add_command(label="Seleccionar pares", command=lambda: self.seleccionar_por_paridad(par=True))
        menu.add_command(label="Seleccionar impares", command=lambda: self.seleccionar_por_paridad(par=False))
        menu.add_separator()
        menu.add_command(label="Invertir selección", command=self.invertir_seleccion)
        menu.add_command(label="Limpiar selección", command=self.limpiar_seleccion)
        menubutton.config(menu=menu)
        menubutton.pack(side="left", padx=5)

        # Entrada de rangos
        tk.Label(top_frame1, text="Rango:").pack(side="left", padx=(10, 2))
        self.rango_entry = tk.Entry(top_frame1, width=18)
        self.rango_entry.pack(side="left")
        tk.Button(top_frame1, text="Aplicar", command=self._aplicar_rango_from_entry).pack(side="left", padx=5)

        self.contador_label = tk.Label(top_frame1, text="Pág. seleccionadas: 0", font=("Arial", 12))
        self.contador_label.pack(side="left", padx=10)

        self.btn_guardar_en = tk.Button(top_frame1, text="Guardar en…", command=self.seleccionar_ruta_guardado, state="disabled")
        self.btn_guardar_en.pack(side="right", padx=5)
        self.btn_guardar_pdf = tk.Button(top_frame1, text="Guardar", command=self.guardar_pdf, state="disabled")
        self.btn_guardar_pdf.pack(side="right", padx=5)

        self.pdf_info_label = tk.Label(top_frame1, text="No hay PDF cargado.", font=("Arial", 8), fg="gray")
        self.pdf_info_label.pack(side="left", padx=10)

        # Fila 2: ON/OFF, unir PDFs
        top_frame2 = tk.Frame(self.main_frame)
        top_frame2.pack(fill="x", pady=(0, 6), padx=6)

        self.btn_onoff = tk.Checkbutton(top_frame2, variable=self.modo_separado, command=self._actualizar_texto_onoff)
        self.btn_onoff.pack(side="left", padx=5)
        self._actualizar_texto_onoff()

        tk.Button(top_frame2, text="Unir PDFs de carpeta", command=self.unir_pdfs_carpeta).pack(side="left", padx=5)

        # Fila 3: Panel nombres (prefijo/sufijo)
        nombres_frame = tk.LabelFrame(self.main_frame, text="Nombres de salida", padx=8, pady=6)
        nombres_frame.pack(fill="x", padx=6, pady=(0, 6))

        tk.Label(nombres_frame, text="Base:").grid(row=0, column=0, sticky="w")
        tk.Entry(nombres_frame, textvariable=self.nombre_base, width=20).grid(row=0, column=1, sticky="w", padx=(0, 8))

        tk.Label(nombres_frame, text="Prefijo:").grid(row=0, column=2, sticky="w")
        tk.Entry(nombres_frame, textvariable=self.prefijo, width=16).grid(row=0, column=3, sticky="w", padx=(0, 8))

        tk.Label(nombres_frame, text="Sufijo:").grid(row=0, column=4, sticky="w")
        tk.Entry(nombres_frame, textvariable=self.sufijo, width=16).grid(row=0, column=5, sticky="w", padx=(0, 8))

        tk.Label(nombres_frame, text="Sep.:").grid(row=0, column=6, sticky="w")
        tk.Entry(nombres_frame, textvariable=self.separador, width=4).grid(row=0, column=7, sticky="w", padx=(0, 8))

        tk.Label(nombres_frame, text="Dígitos:").grid(row=0, column=8, sticky="w")
        tk.Spinbox(nombres_frame, from_=1, to=6, textvariable=self.digitos, width=4, command=self._update_preview).grid(row=0, column=9, sticky="w", padx=(0, 8))

        tk.Label(nombres_frame, text="Inicio #:").grid(row=0, column=10, sticky="w")
        tk.Spinbox(nombres_frame, from_=0, to=9999, textvariable=self.start_num, width=5, command=self._update_preview).grid(row=0, column=11, sticky="w", padx=(0, 8))

        self.preview_label = tk.Label(nombres_frame, text="Ejemplo: ", fg="#555")
        self.preview_label.grid(row=0, column=12, sticky="w", padx=(10, 0))

        for child in nombres_frame.winfo_children():
            if isinstance(child, (tk.Entry, tk.Spinbox)):
                child.bind("<KeyRelease>", lambda e: self._update_preview())

        self._update_preview()

        # Lienzo con miniaturas
        wrapper = tk.Frame(self.main_frame)
        wrapper.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(wrapper)
        self.scroll_y = tk.Scrollbar(wrapper, orient="vertical", command=self.canvas.yview)
        self.frame = tk.Frame(self.canvas)

        self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scroll_y.set)

        self.canvas.pack(fill="both", expand=True, side="left")
        self.scroll_y.pack(fill="y", side="right")

        self.frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._on_mousewheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))
        # Auto-ajustar columnas según ancho (opcional sencillo)
        self.canvas.bind("<Configure>", self._recalcular_columnas)

    def _update_preview(self):
        ejemplo_unico = self._formatear_nombre_salida_unico()
        ejemplo_individual = self._formatear_nombre_individual(1) + ".pdf" if self.num_paginas else "(sin PDF)"
        self.preview_label.config(text=f"Ejemplo único: {ejemplo_unico} | por página: {ejemplo_individual}")

    def _recalcular_columnas(self, event):
        # Ajuste sencillo: recalcula columnas aproximando al ancho disponible
        ancho = max(event.width, self.MINIATURA_ANCHO + 2 * self.MARGEN)
        cols = max(1, int(ancho / (self.MINIATURA_ANCHO + 2 * self.MARGEN + 10)))
        if cols != self.COLUMNAS:
            self.COLUMNAS = cols
            self._repintar_grid()

    def _repintar_grid(self):
        # Reubicar contenedores en nueva grilla
        for i, contenedor in enumerate(self._contenedores):
            contenedor.grid_forget()
            contenedor.grid(row=i // self.COLUMNAS, column=i % self.COLUMNAS, padx=self.MARGEN, pady=self.MARGEN)

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    # ------------------------- Atajos -------------------------
    def _bind_shortcuts(self):
        self.root.bind("<Control-a>", lambda e: (self._sel_all(), "break"))
        self.root.bind("<Control-A>", lambda e: (self._sel_all(), "break"))
        self.root.bind("<Control-i>", lambda e: (self.invertir_seleccion(), "break"))
        self.root.bind("<Control-I>", lambda e: (self.invertir_seleccion(), "break"))
        self.root.bind("<Control-l>", lambda e: (self.limpiar_seleccion(), "break"))
        self.root.bind("<Control-L>", lambda e: (self.limpiar_seleccion(), "break"))
        self.root.bind("<Control-s>", lambda e: (self.guardar_pdf(), "break"))
        self.root.bind("<Control-S>", lambda e: (self.guardar_pdf(), "break"))
        self.root.bind("<Escape>", lambda e: self.limpiar_seleccion())

        self.root.bind("<Left>", lambda e: self._move_cursor(-1, rango=e.state & 0x0001))
        self.root.bind("<Right>", lambda e: self._move_cursor(1,  rango=e.state & 0x0001))
        self.root.bind("<Up>", lambda e: self._move_cursor(-self.COLUMNAS, rango=e.state & 0x0001))
        self.root.bind("<Down>", lambda e: self._move_cursor(self.COLUMNAS,  rango=e.state & 0x0001))

    def _move_cursor(self, delta, rango=False):
        if self.num_paginas == 0:
            return
        nuevo = min(max(self.cursor_index + delta, 0), self.num_paginas - 1)
        if rango and self.last_clicked_index is not None:
            a, b = sorted((self.last_clicked_index, nuevo))
            for i in range(a, b + 1):
                self.seleccionadas[i] = True
        else:
            self.seleccionadas = [False] * self.num_paginas
            self.seleccionadas[nuevo] = True
            self.last_clicked_index = nuevo
        self.cursor_index = nuevo
        self.actualizar_ui()

    def _sel_all(self):
        if self.num_paginas:
            self.seleccionadas = [True] * self.num_paginas
            self.actualizar_ui()

    def _aplicar_rango_from_entry(self):
        txt = self.rango_entry.get().strip()
        if not txt:
            return
        self._aplicar_rango(txt)

    def _aplicar_rango(self, txt):
        selec = [False] * self.num_paginas
        for part in txt.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                try:
                    a, b = [int(x) for x in part.split("-", 1)]
                except ValueError:
                    continue
                if a > b:
                    a, b = b, a
                for i in range(a, b + 1):
                    if 1 <= i <= self.num_paginas:
                        selec[i - 1] = True
            else:
                if part.isdigit():
                    i = int(part)
                    if 1 <= i <= self.num_paginas:
                        selec[i - 1] = True
        self.seleccionadas = selec
        # set cursor/anchor razonable
        try:
            self.cursor_index = next(idx for idx, v in enumerate(selec) if v)
            self.last_clicked_index = self.cursor_index
        except StopIteration:
            self.cursor_index = 0
            self.last_clicked_index = None
        self.actualizar_ui()

    # ------------------------- PDF -------------------------
    def resetear_pdf(self):
        if self.doc:
            try:
                self.doc.close()
            except Exception:
                pass
        self.doc = None
        self.num_paginas = 0
        self.seleccionadas.clear()
        self.labels.clear()
        self.labels_num.clear()
        self.imagenes_tk.clear()
        self.last_clicked_index = None
        self.dragging = False
        self.indices_visitados.clear()
        for widget in self.frame.winfo_children():
            widget.destroy()
        tk.Label(self.frame, text="No hay PDF cargado.", font=("Arial", 14)).pack(pady=20)
        self.actualizar_ui()
        self.btn_guardar_en.config(state="disabled")
        self.btn_guardar_pdf.config(state="disabled")

    def cargar_pdf(self, ruta):
        try:
            self.resetear_pdf()
            self.pdf_info_label.config(text="No hay PDF cargado.", fg="gray")
            self.root.update()

            self.doc = fitz.open(ruta)
            self.num_paginas = self.doc.page_count
            self.seleccionadas = [False] * self.num_paginas

            carpeta_salida = os.path.join(os.path.dirname(os.path.dirname(ruta)), "AR_PDF-NOVA")
            os.makedirs(carpeta_salida, exist_ok=True)
            # nombre por defecto único (usando panel)
            self.ruta_nuevo_pdf = os.path.join(carpeta_salida, self._formatear_nombre_salida_unico())

            self.crear_preview_hilo()
            self.btn_guardar_en.config(state="normal")
            self.btn_guardar_pdf.config(state="normal")
            self._update_preview()
        except Exception as e:
            self._show_banner(f"Error: No se pudo abrir el PDF. {e}", ok=False)

    # ------------------------- Guardar PDF -------------------------
    def guardar_pdf(self):
        if not self.doc:
            self._show_banner("Aviso: No hay PDF cargado.", ok=False)
            return
        if sum(self.seleccionadas) == 0:
            self._show_banner("Aviso: No hay páginas seleccionadas para guardar.", ok=False)
            return
        if not self.ruta_nuevo_pdf or not os.path.isdir(os.path.dirname(self.ruta_nuevo_pdf)):
            self.seleccionar_ruta_guardado()
            if not self.ruta_nuevo_pdf:
                return
        if self.modo_separado.get():
            threading.Thread(target=self._guardar_pdf_individual_thread, daemon=True).start()
        else:
            threading.Thread(target=self._guardar_pdf_unico_thread, daemon=True).start()

    def _guardar_pdf_unico_thread(self):
        try:
            writer = fitz.open()
            paginas_a_guardar = sum(self.seleccionadas)
            self._crear_ventana_progreso("Guardando PDF único…", paginas_a_guardar)
            for i, sel in enumerate(self.seleccionadas):
                if sel:
                    writer.insert_pdf(self.doc, from_page=i, to_page=i)
                    self.root.after(0, self.progress.step, 1)
            # Guardado atómico + nombre con patrón único
            dir_ = os.path.dirname(self.ruta_nuevo_pdf)
            base_nombre = self._formatear_nombre_salida_unico()
            destino_final = os.path.join(dir_, base_nombre)
            fd, tmp = tempfile.mkstemp(prefix="novapdf_", suffix=".pdf", dir=dir_)
            os.close(fd)
            writer.save(tmp)
            writer.close()
            os.replace(tmp, destino_final)
            self._cerrar_progreso_y_abrir_carpeta(destino_final)
            self._show_banner(f"PDF guardado: {destino_final}", ok=True)
        except Exception as e:
            self._show_banner(f"Error al guardar: {e}", ok=False)

    def _guardar_pdf_individual_thread(self):
        try:
            carpeta = os.path.dirname(self.ruta_nuevo_pdf)
            paginas_a_guardar = sum(self.seleccionadas)
            self._crear_ventana_progreso("Guardando PDFs individuales…", paginas_a_guardar)
            contador = 0
            for i, sel in enumerate(self.seleccionadas):
                if sel:
                    writer = fitz.open()
                    writer.insert_pdf(self.doc, from_page=i, to_page=i)
                    # nombre por página con prefijo/sufijo/dígitos
                    nombre = self._formatear_nombre_individual(self.start_num.get() + contador) + ".pdf"
                    ruta_individual = os.path.join(carpeta, nombre)
                    fd, tmp = tempfile.mkstemp(prefix="novapdf_", suffix=".pdf", dir=carpeta)
                    os.close(fd)
                    writer.save(tmp)
                    writer.close()
                    os.replace(tmp, ruta_individual)
                    contador += 1
                    self.root.after(0, self.progress.step, 1)
            self._cerrar_progreso_y_abrir_carpeta(carpeta)
            self._show_banner(f"PDFs guardados en: {carpeta}", ok=True)
        except Exception as e:
            self._show_banner(f"Error al guardar: {e}", ok=False)

    def _formatear_nombre_salida_unico(self):
        """
        Nombre del PDF único (con .pdf al final). Respeta Prefijo/Base/Sufijo.
        Ej: prefijo='Lote', base='MyPDF_', sep='_', sufijo='RevA' => 'Lote_MyPDF__RevA.pdf'
        """
        sep = self.separador.get()
        piezas = [p for p in [self.prefijo.get(), self.nombre_base.get(), self.sufijo.get()] if p != ""]
        nombre = sep.join(piezas) if piezas else "Salida"
        if not nombre.lower().endswith(".pdf"):
            nombre += ".pdf"
        # Sanitizar simple
        return "".join(c for c in nombre if c not in r'\/:*?"<>|')

    def _formatear_nombre_individual(self, numero_corr):
        """
        Nombre base por página (sin .pdf). Usa Prefijo + Base + número con ceros + Sufijo.
        Ej: 'PRE_MyPDF__001_SFX'
        """
        sep = self.separador.get()
        d = max(self.digitos.get(), 1)
        num_txt = str(numero_corr).zfill(d)
        piezas = [p for p in [self.prefijo.get(), self.nombre_base.get() + num_txt, self.sufijo.get()] if p != ""]
        nombre = sep.join(piezas) if piezas else f"Pagina_{num_txt}"
        return "".join(c for c in nombre if c not in r'\/:*?"<>|')

    def _cerrar_progreso_y_abrir_carpeta(self, ruta_archivo_o_carpeta):
        self.root.after(0, self.progreso_win.destroy)
        carpeta = ruta_archivo_o_carpeta
        if os.path.isfile(ruta_archivo_o_carpeta):
            carpeta = os.path.dirname(ruta_archivo_o_carpeta)
        try:
            if sys.platform.startswith("win"):
                os.startfile(carpeta)
            elif sys.platform == "darwin":
                os.system(f'open "{carpeta}"')
            else:
                os.system(f'xdg-open "{carpeta}"')
        except Exception:
            pass

    # ------------------------- Preview -------------------------
    def crear_preview_hilo(self):
        if not self.doc:
            return
        self._crear_ventana_progreso("Cargando miniaturas…", self.num_paginas)
        try:
            self.progreso_win.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))
        except Exception:
            pass
        threading.Thread(target=self._crear_preview_thread, daemon=True).start()

    def _crear_preview_thread(self):
        for widget in self.frame.winfo_children():
            widget.destroy()
        self.labels.clear()
        self.labels_num.clear()
        self.imagenes_tk.clear()
        self._contenedores = []

        for i in range(self.num_paginas):
            pagina = self.doc[i]
            rect = pagina.rect
            escala = max(self.MINIATURA_ANCHO / max(1, rect.width), self.MINIATURA_ALTO / max(1, rect.height))
            escala = min(max(escala, 0.5), 2.0)
            pix = pagina.get_pixmap(matrix=fitz.Matrix(escala, escala))
            img = Image.open(io.BytesIO(pix.tobytes("png"))).resize(
                (self.MINIATURA_ANCHO, self.MINIATURA_ALTO), Image.LANCZOS
            )
            img_tk = ImageTk.PhotoImage(img)
            self.imagenes_tk.append(img_tk)
            self.root.after(0, self._crear_miniatura_ui, i, img_tk)
            self.root.after(0, self.progress.step, 1)

        self.root.after(0, self.progreso_win.destroy)

    def _crear_miniatura_ui(self, i, img_tk):
        contenedor = tk.Frame(self.frame)
        contenedor.grid(row=i // self.COLUMNAS, column=i % self.COLUMNAS, padx=self.MARGEN, pady=self.MARGEN)
        self._contenedores.append(contenedor)

        lbl_img = tk.Label(contenedor, image=img_tk, borderwidth=2, relief="solid",
                           highlightthickness=2, highlightbackground=self.COLOR_NO_SELECCIONADO)
        lbl_img.pack()
        lbl_img.bind("<Button-1>", lambda e, idx=i: self.seleccion_click(idx, e))
        lbl_img.bind("<B1-Motion>", lambda e, idx=i: self.arrastre_toggle(idx))
        lbl_img.bind("<ButtonRelease-1>", lambda e: self.terminar_drag())
        lbl_img.bind("<Double-Button-1>", lambda e, idx=i: self._abrir_zoom(idx))  # <-- ZOOM MODAL
        self.labels.append(lbl_img)

        lbl_num = tk.Label(contenedor, text=f"Pág. {i+1}", font=("Arial", 10))
        lbl_num.pack(pady=2)
        self.labels_num.append(lbl_num)

    # ------------------------- Visor/Zoom -------------------------
    def _abrir_zoom(self, index):
        if not self.doc:
            return
        top = tk.Toplevel(self.root)
        top.title(f"Vista previa — Página {index+1}")
        top.geometry("900x700")
        top.transient(self.root)

        # Controles
        ctrl = tk.Frame(top)
        ctrl.pack(fill="x", padx=8, pady=6)

        tk.Label(ctrl, text=f"Pág. {index+1}").pack(side="left", padx=(0, 10))

        tk.Label(ctrl, text="Zoom:").pack(side="left")
        zoom_var = tk.DoubleVar(value=1.5)
        zoom_scale = tk.Scale(ctrl, from_=0.5, to=4.0, resolution=0.1, orient="horizontal",
                              length=200, variable=zoom_var)
        zoom_scale.pack(side="left", padx=6)

        rot_var = tk.IntVar(value=0)

        def do_render():
            page = self.doc[index]
            z = zoom_var.get()
            r = rot_var.get() % 360
            m = fitz.Matrix(z, z)
            pix = page.get_pixmap(matrix=m, rotation=r)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            img_tk = ImageTk.PhotoImage(img)
            image_label.config(image=img_tk)
            image_label.image = img_tk

        tk.Button(ctrl, text="↺ 90°", command=lambda: (rot_var.set((rot_var.get() - 90) % 360), do_render())).pack(side="left", padx=4)
        tk.Button(ctrl, text="↻ 90°", command=lambda: (rot_var.set((rot_var.get() + 90) % 360), do_render())).pack(side="left", padx=4)
        tk.Button(ctrl, text="Ajustar", command=do_render).pack(side="left", padx=8)

        canvas = tk.Canvas(top, bg="#111")
        canvas.pack(fill="both", expand=True)
        image_label = tk.Label(canvas, bg="#111")
        image_label.place(relx=0.5, rely=0.5, anchor="center")

        # render inicial
        do_render()

    # ------------------------- Selección -------------------------
    def seleccion_click(self, index, event):
        shift = (event.state & 0x0001) != 0
        ctrl = (event.state & 0x0004) != 0
        self.dragging = True
        self.indices_visitados = set()

        if shift and self.last_clicked_index is not None:
            a, b = sorted((self.last_clicked_index, index))
            for i in range(a, b + 1):
                self.seleccionadas[i] = True
        elif ctrl:
            self.seleccionadas[index] = not self.seleccionadas[index]
        else:
            self.seleccionadas = [False] * self.num_paginas
            self.seleccionadas[index] = True

        self.last_clicked_index = index
        self.cursor_index = index
        self.indices_visitados.add(index)
        self.actualizar_ui()

    def arrastre_toggle(self, index):
        if self.dragging and index not in self.indices_visitados:
            estado_inicio = self.seleccionadas[self.last_clicked_index] if self.last_clicked_index is not None else True
            self.seleccionadas[index] = estado_inicio
            self.indices_visitados.add(index)
            self.actualizar_ui()

    def terminar_drag(self):
        self.dragging = False
        self.indices_visitados.clear()

    def toggle_todas_paginas(self):
        estado = not all(self.seleccionadas)
        self.seleccionadas = [estado] * self.num_paginas
        self.actualizar_ui()

    def seleccionar_por_paridad(self, par=True):
        self.seleccionadas = [((i + 1) % 2 == 0) if par else ((i + 1) % 2 == 1)
                              for i in range(self.num_paginas)]
        self.actualizar_ui()

    def invertir_seleccion(self):
        self.seleccionadas = [not v for v in self.seleccionadas]
        self.actualizar_ui()

    def limpiar_seleccion(self):
        self.seleccionadas = [False] * self.num_paginas
        self.actualizar_ui()

    # ------------------------- UI Helper -------------------------
    def actualizar_ui(self):
        for i, lbl in enumerate(self.labels):
            seleccionado = self.seleccionadas[i]
            color = self.COLOR_SELECCIONADO if seleccionado else self.COLOR_NO_SELECCIONADO
            lbl.config(
                borderwidth=4 if seleccionado else 2,
                relief="solid",
                highlightbackground=color,
                highlightcolor=color,
                highlightthickness=2
            )
            self.labels_num[i].config(fg=color if seleccionado else "black")
        self.contador_label.config(text=f"Pág. seleccionadas: {sum(self.seleccionadas)}")

    def seleccionar_archivo_pdf(self):
        ruta = filedialog.askopenfilename(title="Seleccionar archivo PDF", filetypes=[("PDF", "*.pdf")])
        if ruta:
            self.cargar_pdf(ruta)
            self.pdf_info_label.config(text=f"Ruta: {ruta}", fg="black")

    def seleccionar_ruta_guardado(self):
        # Proponer nombre único según panel
        nombre_defecto = self._formatear_nombre_salida_unico()
        ruta = filedialog.asksaveasfilename(title="Guardar como PDF", initialfile=nombre_defecto,
                                            defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if ruta:
            self.ruta_nuevo_pdf = ruta

    def _crear_preview_inicial(self):
        tk.Label(self.frame, text="No hay PDF cargado.", font=("Arial", 14)).pack(pady=20)

    def _actualizar_texto_onoff(self):
        if self.modo_separado.get():
            self.btn_onoff.config(text="Hojas separadas (ON)")
        else:
            self.btn_onoff.config(text="Todo en un PDF (ON)")

    def _show_banner(self, texto, ok=True, dur_ms=5000):
        if ok:
            self.banner.config(text=texto, bg="#e6f0ff", fg="#0b57d0")
        else:
            self.banner.config(text=texto, bg="#fdecea", fg="#b3261e")
        self.banner.pack(fill="x", before=self.main_frame.winfo_children()[0])
        self.root.after_cancel(getattr(self, "_banner_after_id", self.root.after(0, lambda: None)))
        self._banner_after_id = self.root.after(dur_ms, self._hide_banner)

    def _hide_banner(self):
        try:
            self.banner.pack_forget()
        except Exception:
            pass

    # ------------------------- Ventana progreso -------------------------
    def _crear_ventana_progreso(self, texto="Procesando…", max_val=100):
        self.progreso_win = tk.Toplevel(self.root)
        self.progreso_win.title(texto)
        self.progreso_win.geometry("420x110")
        self.progreso_win.resizable(False, False)
        self.progreso_win.transient(self.root)
        self.progreso_win.grab_set()

        tk.Label(self.progreso_win, text=texto, font=("Arial", 12)).pack(pady=5)
        self.progress = ttk.Progressbar(self.progreso_win, orient="horizontal", length=360, mode="determinate")
        self.progress.pack(pady=5)
        self.progress["maximum"] = max_val
        self.progress["value"] = 0

    # ------------------------- Unir PDFs -------------------------
    def unir_pdfs_carpeta(self):
        carpeta = filedialog.askdirectory(title="Seleccionar carpeta con PDFs")
        if carpeta:
            try:
                unir_pdfs(carpeta)
                self._show_banner(f"Listo: Se unieron los PDFs de la carpeta: {carpeta}", ok=True)
            except Exception as e:
                self._show_banner(f"Error al unir PDFs: {e}", ok=False)


# ------------------------- Inicializar la aplicación -------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = PDFSelectorApp(root)
    root.mainloop()
