import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import io
import os
import sys
import threading
from Parte_00 import unir_pdfs  # Función externa para unir PDFs


class PDFSelectorApp:
    MINIATURA_ANCHO = 140
    MINIATURA_ALTO = 190
    COLUMNAS = 8
    MARGEN = 5
    COLOR_SELECCIONADO = "blue"
    COLOR_NO_SELECCIONADO = "gray"

    def __init__(self, root):
        self.root = root
        self.root.title("NovaPDF_AR.vr.0002")
        self.root.geometry("1300x650+10+10")
        try:
            self.root.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))
        except Exception:
            pass  # En macOS/Linux .ico no aplica, evitamos crashear

        # Variables PDF
        self.doc = None
        self.num_paginas = 0
        self.seleccionadas = []
        self.labels = []
        self.labels_num = []
        self.imagenes_tk = []

        # Ruta de guardado
        self.ruta_nuevo_pdf = ""

        # Selección
        self.last_clicked_index = None
        self.dragging = False
        self.indices_visitados = set()
        self.modo_separado = tk.BooleanVar(value=False)

        self._crear_interface()
        self._crear_preview_inicial()

    # ------------------------- UI -------------------------
    def _crear_interface(self):
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)

        # Barra de avisos (oculta por defecto)
        self.banner = tk.Label(
            self.main_frame, text="", bg="#e6f0ff", fg="#0b57d0",
            font=("Arial", 10), anchor="w", padx=10
        )
        self.banner.pack(fill="x")
        self.banner.pack_forget()  # Ocultamos hasta usar

        # Fila de botones
        top_frame1 = tk.Frame(self.main_frame)
        top_frame1.pack(fill="x", pady=5, padx=5)

        tk.Button(top_frame1, text="Abrir PDF", command=self.seleccionar_archivo_pdf).pack(side="left", padx=5)

        menubutton = tk.Menubutton(top_frame1, text="Selección…", relief="raised")
        menu = tk.Menu(menubutton, tearoff=0)
        menu.add_command(label="Seleccionar/Deseleccionar (Todas)", command=self.toggle_todas_paginas)
        menu.add_separator()
        menu.add_command(label="Seleccionar pares", command=lambda: self.seleccionar_por_paridad(par=True))
        menu.add_command(label="Seleccionar impares", command=lambda: self.seleccionar_por_paridad(par=False))
        menu.add_separator()
        menu.add_command(label="Invertir selección", command=self.invertir_seleccion)
        menu.add_command(label="Limpiar selección", command=self.limpiar_seleccion)
        menubutton.config(menu=menu)
        menubutton.pack(side="left", padx=5)

        self.contador_label = tk.Label(top_frame1, text="Pág. seleccionadas: 0", font=("Arial", 12))
        self.contador_label.pack(side="left", padx=10)

        self.btn_guardar_en = tk.Button(top_frame1, text="Guardar en…", command=self.seleccionar_ruta_guardado, state="disabled")
        self.btn_guardar_en.pack(side="right", padx=5)
        self.btn_guardar_pdf = tk.Button(top_frame1, text="Guardar como PDF", command=self.guardar_pdf, state="disabled")
        self.btn_guardar_pdf.pack(side="right", padx=5)

        self.pdf_info_label = tk.Label(top_frame1, text="No hay PDF cargado.", font=("Arial", 8), fg="gray")
        self.pdf_info_label.pack(side="left", padx=10)

        # Fila ON/OFF y unir PDFs
        top_frame2 = tk.Frame(self.main_frame)
        top_frame2.pack(fill="x", pady=5, padx=5)

        self.btn_onoff = tk.Checkbutton(top_frame2, variable=self.modo_separado, command=self._actualizar_texto_onoff)
        self.btn_onoff.pack(side="left", padx=5)
        self._actualizar_texto_onoff()

        tk.Button(top_frame2, text="Unir PDFs de carpeta", command=self.unir_pdfs_carpeta).pack(side="left", padx=5)

        # Canvas y Scrollbar
        wrapper = tk.Frame(self.main_frame)
        wrapper.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(wrapper)
        self.scroll_y = tk.Scrollbar(wrapper, orient="vertical", command=self.canvas.yview)
        self.frame = tk.Frame(self.canvas)

        self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scroll_y.set)

        self.canvas.pack(fill="both", expand=True, side="left")
        self.scroll_y.pack(fill="y", side="right")

        self.frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        # Scroll de rueda SOLO cuando el puntero esté sobre el canvas
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._on_mousewheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

    def _on_mousewheel(self, event):
        # Windows/Mac: event.delta +/-120 múltiplos; Linux puede usar Button-4/5 (no lo manejamos aquí)
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    # ------------------------- PDF -------------------------
    def resetear_pdf(self):
        if self.doc:
            try:
                self.doc.close()
            except Exception:
                pass
        self.doc = None
        self.num_paginas = 0
        self.seleccionadas.clear()
        self.labels.clear()
        self.labels_num.clear()
        self.imagenes_tk.clear()
        self.last_clicked_index = None
        self.dragging = False
        self.indices_visitados.clear()
        for widget in self.frame.winfo_children():
            widget.destroy()
        tk.Label(self.frame, text="No hay PDF cargado.", font=("Arial", 14)).pack(pady=20)
        self.actualizar_ui()
        self.btn_guardar_en.config(state="disabled")
        self.btn_guardar_pdf.config(state="disabled")

    def cargar_pdf(self, ruta):
        try:
            self.resetear_pdf()
            self.pdf_info_label.config(text="No hay PDF cargado.", fg="gray")
            self.root.update()

            self.doc = fitz.open(ruta)
            self.num_paginas = self.doc.page_count
            self.seleccionadas = [False] * self.num_paginas

            carpeta_salida = os.path.join(os.path.dirname(os.path.dirname(ruta)), "AR_PDF-NOVA")
            os.makedirs(carpeta_salida, exist_ok=True)
            self.ruta_nuevo_pdf = os.path.join(carpeta_salida, "MyPDF_.pdf")

            self.crear_preview_hilo()
            self.btn_guardar_en.config(state="normal")
            self.btn_guardar_pdf.config(state="normal")
        except Exception as e:
            self._show_banner(f"Error: No se pudo abrir el PDF. {e}", ok=False)

    # ------------------------- Guardar PDF -------------------------
    def guardar_pdf(self):
        if not self.doc:
            self._show_banner("Aviso: No hay PDF cargado.", ok=False)
            return
        if sum(self.seleccionadas) == 0:
            self._show_banner("Aviso: No hay páginas seleccionadas para guardar.", ok=False)
            return
        if not self.ruta_nuevo_pdf or not os.path.isdir(os.path.dirname(self.ruta_nuevo_pdf)):
            self.seleccionar_ruta_guardado()
            if not self.ruta_nuevo_pdf:
                return
        if self.modo_separado.get():
            threading.Thread(target=self._guardar_pdf_individual_thread, daemon=True).start()
        else:
            threading.Thread(target=self._guardar_pdf_unico_thread, daemon=True).start()

    def _guardar_pdf_unico_thread(self):
        try:
            writer = fitz.open()
            paginas_a_guardar = sum(self.seleccionadas)
            self._crear_ventana_progreso("Guardando PDF único…", paginas_a_guardar)
            for i, sel in enumerate(self.seleccionadas):
                if sel:
                    writer.insert_pdf(self.doc, from_page=i, to_page=i)
                    self.root.after(0, self.progress.step, 1)
            writer.save(self.ruta_nuevo_pdf)
            writer.close()
            self._cerrar_progreso_y_abrir_carpeta(self.ruta_nuevo_pdf)
            self._show_banner(f"PDF guardado: {self.ruta_nuevo_pdf}", ok=True)
        except Exception as e:
            self._show_banner(f"Error al guardar: {e}", ok=False)

    def _guardar_pdf_individual_thread(self):
        try:
            carpeta = os.path.dirname(self.ruta_nuevo_pdf)
            base = os.path.splitext(os.path.basename(self.ruta_nuevo_pdf))[0]
            paginas_a_guardar = sum(self.seleccionadas)
            self._crear_ventana_progreso("Guardando PDFs individuales…", paginas_a_guardar)
            for i, sel in enumerate(self.seleccionadas):
                if sel:
                    writer = fitz.open()
                    writer.insert_pdf(self.doc, from_page=i, to_page=i)
                    ruta_individual = os.path.join(carpeta, f"{base}_Pag_{i+1}.pdf")
                    writer.save(ruta_individual)
                    writer.close()
                    self.root.after(0, self.progress.step, 1)
            self._cerrar_progreso_y_abrir_carpeta(carpeta)
            self._show_banner(f"PDFs guardados en: {carpeta}", ok=True)
        except Exception as e:
            self._show_banner(f"Error al guardar: {e}", ok=False)

    def _cerrar_progreso_y_abrir_carpeta(self, ruta_archivo_o_carpeta):
        self.root.after(0, self.progreso_win.destroy)
        carpeta = ruta_archivo_o_carpeta
        if os.path.isfile(ruta_archivo_o_carpeta):
            carpeta = os.path.dirname(ruta_archivo_o_carpeta)
        # Abrir carpeta de forma multiplataforma
        try:
            if sys.platform.startswith("win"):
                os.startfile(carpeta)  # Windows
            elif sys.platform == "darwin":
                os.system(f'open "{carpeta}"')  # macOS
            else:
                os.system(f'xdg-open "{carpeta}"')  # Linux
        except Exception:
            pass

    # ------------------------- Preview -------------------------
    def crear_preview_hilo(self):
        if not self.doc:
            return
        self._crear_ventana_progreso("Cargando miniaturas, por favor espere…", self.num_paginas)
        try:
            self.progreso_win.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))
        except Exception:
            pass
        threading.Thread(target=self._crear_preview_thread, daemon=True).start()

    def _crear_preview_thread(self):
        for widget in self.frame.winfo_children():
            widget.destroy()
        self.labels.clear()
        self.labels_num.clear()
        self.imagenes_tk.clear()

        # Render escalado directo desde PDF evitando reescalar con PIL más de lo necesario
        for i in range(self.num_paginas):
            pagina = self.doc[i]
            # Calcular escala para acercarnos al ancho deseado
            rect = pagina.rect
            escala = max(self.MINIATURA_ANCHO / max(1, rect.width), self.MINIATURA_ALTO / max(1, rect.height))
            # Límite razonable
            escala = min(max(escala, 0.5), 2.0)
            pix = pagina.get_pixmap(matrix=fitz.Matrix(escala, escala))
            img = Image.open(io.BytesIO(pix.tobytes("png"))).resize(
                (self.MINIATURA_ANCHO, self.MINIATURA_ALTO), Image.LANCZOS
            )
            img_tk = ImageTk.PhotoImage(img)
            self.imagenes_tk.append(img_tk)
            self.root.after(0, self._crear_miniatura_ui, i, img_tk)
            self.root.after(0, self.progress.step, 1)

        self.root.after(0, self.progreso_win.destroy)

    def _crear_miniatura_ui(self, i, img_tk):
        contenedor = tk.Frame(self.frame)
        contenedor.grid(row=i // self.COLUMNAS, column=i % self.COLUMNAS, padx=self.MARGEN, pady=self.MARGEN)

        lbl_img = tk.Label(contenedor, image=img_tk, borderwidth=2, relief="solid",
                           highlightthickness=2, highlightbackground=self.COLOR_NO_SELECCIONADO)
        lbl_img.pack()
        lbl_img.bind("<Button-1>", lambda e, idx=i: self.seleccion_click(idx, e))
        lbl_img.bind("<B1-Motion>", lambda e, idx=i: self.arrastre_toggle(idx))
        lbl_img.bind("<ButtonRelease-1>", lambda e: self.terminar_drag())
        self.labels.append(lbl_img)

        lbl_num = tk.Label(contenedor, text=f"Pág. {i+1}", font=("Arial", 10))
        lbl_num.pack(pady=2)
        self.labels_num.append(lbl_num)

    # ------------------------- Selección -------------------------
    def seleccion_click(self, index, event):
        shift = (event.state & 0x0001) != 0
        ctrl = (event.state & 0x0004) != 0
        self.dragging = True
        self.indices_visitados = set()

        if shift and self.last_clicked_index is not None:
            a, b = sorted((self.last_clicked_index, index))
            for i in range(a, b + 1):
                self.seleccionadas[i] = True
        elif ctrl:
            self.seleccionadas[index] = not self.seleccionadas[index]
        else:
            self.seleccionadas = [False] * self.num_paginas
            self.seleccionadas[index] = True

        self.last_clicked_index = index
        self.indices_visitados.add(index)
        self.actualizar_ui()

    def arrastre_toggle(self, index):
        if self.dragging and index not in self.indices_visitados:
            # Activamos (no alternamos) si el punto de inicio estaba activado; si no, desactivamos
            estado_inicio = self.seleccionadas[self.last_clicked_index] if self.last_clicked_index is not None else True
            self.seleccionadas[index] = estado_inicio
            self.indices_visitados.add(index)
            self.actualizar_ui()

    def terminar_drag(self):
        self.dragging = False
        self.indices_visitados.clear()

    def toggle_todas_paginas(self):
        estado = not all(self.seleccionadas)
        self.seleccionadas = [estado] * self.num_paginas
        self.actualizar_ui()

    def seleccionar_por_paridad(self, par=True):
        # 1-based: páginas pares => (i+1) % 2 == 0; impares => (i+1) % 2 == 1
        self.seleccionadas = [((i + 1) % 2 == 0) if par else ((i + 1) % 2 == 1)
                              for i in range(self.num_paginas)]
        self.actualizar_ui()

    def invertir_seleccion(self):
        self.seleccionadas = [not v for v in self.seleccionadas]
        self.actualizar_ui()

    def limpiar_seleccion(self):
        self.seleccionadas = [False] * self.num_paginas
        self.actualizar_ui()

    # ------------------------- UI Helper -------------------------
    def actualizar_ui(self):
        for i, lbl in enumerate(self.labels):
            seleccionado = self.seleccionadas[i]
            color = self.COLOR_SELECCIONADO if seleccionado else self.COLOR_NO_SELECCIONADO
            lbl.config(
                borderwidth=4 if seleccionado else 2,
                relief="solid",
                highlightbackground=color,
                highlightcolor=color,
                highlightthickness=2
            )
            self.labels_num[i].config(fg=color if seleccionado else "black")
        self.contador_label.config(text=f"Pág. seleccionadas: {sum(self.seleccionadas)}")

    def seleccionar_archivo_pdf(self):
        ruta = filedialog.askopenfilename(title="Seleccionar archivo PDF", filetypes=[("PDF", "*.pdf")])
        if ruta:
            self.cargar_pdf(ruta)
            self.pdf_info_label.config(text=f"Ruta: {ruta}", fg="black")

    def seleccionar_ruta_guardado(self):
        nombre_defecto = os.path.basename(self.ruta_nuevo_pdf) if self.ruta_nuevo_pdf else "PDF_Separado.pdf"
        ruta = filedialog.asksaveasfilename(title="Guardar como PDF", initialfile=nombre_defecto,
                                            defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if ruta:
            self.ruta_nuevo_pdf = ruta

    def _crear_preview_inicial(self):
        tk.Label(self.frame, text="No hay PDF cargado.", font=("Arial", 14)).pack(pady=20)

    def _actualizar_texto_onoff(self):
        if self.modo_separado.get():
            self.btn_onoff.config(text="Hojas separadas (ON)")
        else:
            self.btn_onoff.config(text="Todo en un PDF (ON)")

    def _show_banner(self, texto, ok=True, dur_ms=5000):
        # Colores: azul para ok, rojo suave para error/aviso
        if ok:
            self.banner.config(text=texto, bg="#e6f0ff", fg="#0b57d0")
        else:
            self.banner.config(text=texto, bg="#fdecea", fg="#b3261e")
        self.banner.pack(fill="x", before=self.main_frame.winfo_children()[0])
        self.root.after_cancel(getattr(self, "_banner_after_id", self.root.after(0, lambda: None)))
        self._banner_after_id = self.root.after(dur_ms, self._hide_banner)

    def _hide_banner(self):
        try:
            self.banner.pack_forget()
        except Exception:
            pass

    # ------------------------- Ventana progreso -------------------------
    def _crear_ventana_progreso(self, texto="Procesando…", max_val=100):
        self.progreso_win = tk.Toplevel(self.root)
        self.progreso_win.title(texto)
        self.progreso_win.geometry("420x90")
        self.progreso_win.resizable(False, False)
        self.progreso_win.transient(self.root)
        self.progreso_win.grab_set()

        tk.Label(self.progreso_win, text=texto, font=("Arial", 12)).pack(pady=5)
        self.progress = ttk.Progressbar(self.progreso_win, orient="horizontal", length=360, mode="determinate")
        self.progress.pack(pady=5)
        self.progress["maximum"] = max_val
        self.progress["value"] = 0

    # ------------------------- Unir PDFs -------------------------
    def unir_pdfs_carpeta(self):
        carpeta = filedialog.askdirectory(title="Seleccionar carpeta con PDFs")
        if carpeta:
            try:
                unir_pdfs(carpeta)
                self._show_banner(f"Listo: Se unieron los PDFs de la carpeta: {carpeta}", ok=True)
            except Exception as e:
                self._show_banner(f"Error al unir PDFs: {e}", ok=False)


# ------------------------- Inicializar la aplicación -------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = PDFSelectorApp(root)
    root.mainloop()
