import os
import tkinter as tk
from Back import GIFBackgroundWindow
from Parte_01 import PDFSelectorApp
from Parte_02 import PDFRotatorGridApp
from Parte_03 import PDFPageReorderApp

# Crear ventana con GIF animado


ruta_base = os.path.dirname(os.path.abspath(__file__))
ruta_gif = os.path.join(ruta_base, "fondo.gif")
ruta_icon = os.path.join(ruta_base, "Mi_icon_01.ico")

ventana_gif = GIFBackgroundWindow(ruta_gif, ruta_icon, width=550, height=250, title="PDF Manager")



# ventana_gif = GIFBackgroundWindow("fondo.gif", "Mi_icon_01.ico", width=550, height=250, title="PDF Manager")

# Configurar columnas para que se distribuyan uniformemente
for i in range(3):
    ventana_gif.ventana.grid_columnconfigure(i, weight=1)
    
# Header
barra_superior = tk.Frame(ventana_gif.ventana, bg="#0088FF", height=25)
barra_superior.grid(row=0, column=0, columnspan=3, sticky="we")  # abarca 3 columnas # ocupa toda la fila superior
lbl_titulo = tk.Label(barra_superior, text="Proyecto: 01", bg="#0088FF", fg="white", font=("Segoe UI", 10, "bold"))
lbl_titulo.pack(side="left", padx=5)

# Clase para definir botones
class Constrir_boton:
    def __init__(self, etiqueta, numEtiqueta,comando=None):  
        self.btn_generico = tk.Button(ventana_gif.ventana, text=etiqueta, width=20, height=3,command=comando)
        self.btn_generico.grid(row=1, column=numEtiqueta, padx=5, pady=5)



# Función genérica para abrir una ventana secundaria y ocultar la principal
def abrir_ventana_secundaria(clase_app):
    # Ocultar ventana principal
    ventana_gif.ventana.withdraw()

    # Crear ventana secundaria
    ventana_secundaria = tk.Toplevel()
    app = clase_app(ventana_secundaria)

    # Cuando se cierre la ventana secundaria, mostrar la principal
    def al_cerrar():
        ventana_secundaria.destroy()
        ventana_gif.ventana.deiconify()

    ventana_secundaria.protocol("WM_DELETE_WINDOW", al_cerrar)

# Crear botones con sus respectivas apps
btn_01 = Constrir_boton("Separar/Unir PDF", 0, comando=lambda: abrir_ventana_secundaria(PDFSelectorApp))
btn_02 = Constrir_boton("Rotar PDF", 1, comando=lambda: abrir_ventana_secundaria(PDFRotatorGridApp))
btn_03 = Constrir_boton("Reordenar/Eliminar PDF", 2, comando=lambda: abrir_ventana_secundaria(PDFPageReorderApp))

# Mostrar la ventana
ventana_gif.show()