import os
import io
import threading
import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk

class PDFRotatorGridApp:
    MINIATURA_ANCHO = 140
    MINIATURA_ALTO = 190
    COLUMNAS = 8
    MARGEN = 5
    COLOR_SELECCIONADO = "blue"
    COLOR_NO_SELECCIONADO = "gray"

    def __init__(self, root):
        self.root = root
        self.root.title("SpinPDF_AR_vr.0001")
        self.root.geometry("1300x650+10+10")
        self.root.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))

        # Variables PDF
        self.doc = None
        self.ruta_pdf = None
        self.num_paginas = 0
        self.rotaciones = []
        self.imagenes_originales = []
        self.imagenes_tk = []
        self.labels_imagen = []
        self.labels_num = []
        self.seleccionadas = []
        self.ctrl_pressed = False
        self.last_clicked_index = None

        # UI
        top_frame = tk.Frame(root)
        top_frame.pack(fill="x", pady=5)
        instrucciones = "Ctrl + ← (90° izq) | Ctrl + → (90° der)| Ctrl + ↑ (180°)"
        tk.Label(top_frame, text=instrucciones, font=("Arial", 10), fg="darkgreen").pack(pady=2)
        tk.Button(top_frame, text="Abrir PDF", command=self.seleccionar_pdf).pack(side="left", padx=5)
        self.btn_guardar = tk.Button(top_frame, text="Guardar como...", command=self.guardar_pdf_como, state="disabled")
        self.btn_guardar.pack(side="right", padx=5)
        self.lbl_ruta = tk.Label(top_frame, text="Archivo: Ninguno", font=("Arial", 9))
        self.lbl_ruta.pack(side="bottom", fill="x", pady=2)

        sel_frame = tk.Frame(root)
        sel_frame.pack(fill="x", pady=2)
        for txt, cmd in [("Seleccionar todo", self.seleccionar_todo),
                         ("Deseleccionar todo", self.deseleccionar_todo),
                         ("Seleccionar pares", self.seleccionar_pares),
                         ("Seleccionar impares", self.seleccionar_impares)]:
            tk.Button(sel_frame, text=txt, command=cmd).pack(side="left", padx=2)

        self.canvas = tk.Canvas(root)
        self.scroll_y = tk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
        self.frame = tk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scroll_y.set)
        self.canvas.pack(fill="both", expand=True, side="left")
        self.scroll_y.pack(fill="y", side="right")
        self.frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # Scroll
        self.canvas.bind_all("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        self.canvas.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-1, "units"))
        self.canvas.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll(1, "units"))

        # Teclas
        self.root.bind("<Control-Right>", lambda e: self.rotar_seleccionadas(-90))
        self.root.bind("<Control-Left>", lambda e: self.rotar_seleccionadas(90))
        self.root.bind("<Control-Up>", lambda e: self.rotar_seleccionadas(180))
        self.root.bind("<Control_L>", lambda e: setattr(self, "ctrl_pressed", True))
        self.root.bind("<KeyRelease-Control_L>", lambda e: setattr(self, "ctrl_pressed", False))

    def seleccionar_pdf(self):
        ruta = filedialog.askopenfilename(title="Seleccionar PDF", filetypes=[("PDF Files", "*.pdf")])
        if ruta:
            self.cargar_pdf(ruta)

    def cargar_pdf(self, ruta):
        try:
            if self.doc: self.doc.close()
            self.doc = fitz.open(ruta)
            self.ruta_pdf = ruta
            self.lbl_ruta.config(text=f"Archivo: {ruta}")
            self.num_paginas = self.doc.page_count
            self.rotaciones = [0]*self.num_paginas
            self.imagenes_originales.clear()
            self.imagenes_tk.clear()
            self.labels_imagen.clear()
            self.labels_num.clear()
            self.seleccionadas = [False]*self.num_paginas
            self.last_clicked_index = None
            self.btn_guardar.config(state="normal")
            threading.Thread(target=self.crear_preview, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir el PDF:\n{e}")

    def crear_preview(self):
        for widget in self.frame.winfo_children(): widget.destroy()
        progreso = self._barra_progreso("Cargando PDF...", self.num_paginas)
        for i, pagina in enumerate(self.doc):
            pix = pagina.get_pixmap(matrix=fitz.Matrix(2,2))
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            self.imagenes_originales.append(img)
            miniatura = img.resize((self.MINIATURA_ANCHO, self.MINIATURA_ALTO))
            img_tk = ImageTk.PhotoImage(miniatura)
            self.imagenes_tk.append(img_tk)
            self.root.after(0, lambda i=i, img_tk=img_tk: self.agregar_miniatura(i, img_tk))
            progreso["value"] = i + 1
            progreso.update()
        progreso.master.destroy()

    def _barra_progreso(self, titulo, max_val):
        win = tk.Toplevel(self.root)
        win.title(titulo)
        win.geometry("400x70")
        win.resizable(False, False)
        win.iconbitmap(os.path.join(os.path.dirname(__file__), "Mi_icon_01.ico"))
        tk.Label(win, text=f"{titulo}").pack(pady=5)
        bar = ttk.Progressbar(win, orient="horizontal", length=350, mode="determinate", maximum=max_val)
        bar.pack(pady=10)
        win.update()
        return bar

    def agregar_miniatura(self, i, img_tk):
        cont = tk.Frame(self.frame)
        cont.grid(row=i//self.COLUMNAS, column=i%self.COLUMNAS, padx=self.MARGEN, pady=self.MARGEN)
        lbl = tk.Label(cont, image=img_tk, borderwidth=2, relief="solid", highlightthickness=2)
        lbl.pack()
        lbl.bind("<Button-1>", lambda e, idx=i: self.seleccionar_pagina(idx, e))
        self.labels_imagen.append(lbl)
        lbl_num = tk.Label(cont, text=f"Pág. {i+1} (rot: {self.rotaciones[i]}°)")
        lbl_num.pack(pady=2)
        self.labels_num.append(lbl_num)

    def seleccionar_pagina(self, i, e):
        shift = (e.state & 0x0001)!=0
        if shift and self.last_clicked_index is not None:
            for j in range(min(self.last_clicked_index, i), max(self.last_clicked_index, i)+1):
                self.seleccionadas[j]=True
        elif self.ctrl_pressed:
            self.seleccionadas[i] = not self.seleccionadas[i]
        else:
            self.seleccionadas = [False]*self.num_paginas
            self.seleccionadas[i] = True
        self.last_clicked_index = i
        self.actualizar_ui()

    def actualizar_ui(self):
        for i, lbl in enumerate(self.labels_imagen):
            color = self.COLOR_SELECCIONADO if self.seleccionadas[i] else self.COLOR_NO_SELECCIONADO
            lbl.config(highlightbackground=color, highlightcolor=color)
        for i, lbl in enumerate(self.labels_num):
            lbl.config(text=f"Pág. {i+1} (rot: {self.rotaciones[i]}°)")
            lbl.config(fg="blue" if self.seleccionadas[i] else "black")

    def rotar_seleccionadas(self, grados):
        for i, sel in enumerate(self.seleccionadas):
            if sel:
                self.rotaciones[i] = (self.rotaciones[i]+grados)%360
                img = self.imagenes_originales[i].rotate(self.rotaciones[i], expand=True)
                img = img.resize((self.MINIATURA_ANCHO, self.MINIATURA_ALTO), Image.LANCZOS)
                self.imagenes_tk[i] = ImageTk.PhotoImage(img)
                self.labels_imagen[i].config(image=self.imagenes_tk[i])
        self.actualizar_ui()

    def guardar_pdf_como(self):
        ruta = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files","*.pdf")])
        if not ruta: return
        progreso = self._barra_progreso("Guardando PDF...", self.num_paginas)
        try:
            nuevo_pdf = fitz.open()
            for i, pagina in enumerate(self.doc):
                p = nuevo_pdf.new_page(width=pagina.rect.width, height=pagina.rect.height)
                p.show_pdf_page(pagina.rect, self.doc, i, rotate=self.rotaciones[i])
                progreso["value"] = i+1
                progreso.update()
            nuevo_pdf.save(ruta)
            nuevo_pdf.close()
            progreso.master.destroy()
            messagebox.showinfo("Listo", f"PDF guardado en:\n{ruta}")
        except Exception as e:
            progreso.master.destroy()
            messagebox.showerror("Error", f"No se pudo guardar el PDF:\n{e}")

    # Selección rápida
    def seleccionar_todo(self): self.seleccionadas=[True]*self.num_paginas; self.actualizar_ui()
    def deseleccionar_todo(self): self.seleccionadas=[False]*self.num_paginas; self.actualizar_ui()
    def seleccionar_pares(self): self.seleccionadas=[i%2==1 for i in range(self.num_paginas)]; self.actualizar_ui()
    def seleccionar_impares(self): self.seleccionadas=[i%2==0 for i in range(self.num_paginas)]; self.actualizar_ui()


if __name__=="__main__":
    root=tk.Tk()
    app=PDFRotatorGridApp(root)
    root.mainloop()
